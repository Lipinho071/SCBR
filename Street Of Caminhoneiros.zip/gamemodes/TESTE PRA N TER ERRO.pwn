// �������������������� Gamemode Iniciada 03/11/2020 ���������������������������

// Includes
#include <a_samp>
#include <foreach>
#include <streamer>
#include <sscanf2>
#include <DOF2>
#include <zcmd>
#include <dini>

// Defines Dialogs

#define DIALOG_REGISTRO 0
#define DIALOG_LOGIN 1
#define DIALOG_SEXO 2
#define DIALOG_ARMAS 3
#define DIALOG_BANIDO 4
#define DIALOG_ADMIN 5
#define DIALOG_PM 6
#define DIALOG_PRF 7
#define DIALOG_CONVITE 8
#define DIALOG_AJUDA 9
#define DIALOG_CMD1 10
#define DIALOG_CMD2 11
#define DIALOG_CMD3 12
#define DIALOG_CMD4 13
#define Dial_conseTX 14
#define Diag_Menu_Car 15
#define NIDConseCarsC1 16
#define NIDConseCarsC3 17
#define NIDConseCarsC2 18
#define NIDConseCarsC5 19
#define NIDConseCSell  20
#define NIDConseCor 21
#define SellCarPlyPly 22


//defines
#define   SCBR::%0(%1) 	   	forward %0(%1);\
							public %0(%1)

#undef MAX_VEHICLES
#define MAX_VEHICLES 790

#define QntSlotCar 5
#define PATH "StreetConce"

//Cores
#define 				BRANCO 0xFFFFFFFF
#define 				COR_AMARELO 0xFFFF00FF
#define 				COR_AZUL 0x058AFFFF
#define 				ROSA 0xFF05CDFF
#define 				COR_VERDE 0x33AA33AA
#define 				COR_BRANCO 0xFFFFFFAA
#define					COR_VERMELHO 0xFFFFFFFF
#define 				COR_PRETO 0x000000FF
#define 				COR_CINZA 0x878787FF
#define 				COR_AZULCLARO 0x03F2FFFF
#define					COR_VERDECLARO 0x03FF35FF
#define 				COR_ROXO 0x7D03FFFF
#define 				COR_ROXOCLARO 0x9A03FFFF
#define 				COR_LARANJA 0xFF7403FF
#define 				COR_PURPLE 0xC2A2DAAA

enum pInfo
{
	 Senha,
	 Dinheiro,
	 Sexo,
	 Skin,
	 Admin,
	 Level,
	 Org,
	 Cargo,
	 convite,
	 Arrastado,
	 bool:Trabalhando,
	 bool:Algemado
};

new PlayerInfo[MAX_PLAYERS][pInfo];
new ObjetoAviao[MAX_PLAYERS];
new arquivo[256];
new String[256];
new Refueling[MAX_PLAYERS];
new existe;
new MEGAString[2500];
new CidadePerigosa;

new Mensagens[10][] =
{
	"{F08080}SCBR: Entre Em Nosso Discord Para Ficar Por Dentro Das Atualizacoes! Use https://discord.gg/qRnGadvr7y",
	"{F08080}SCBR: Viu Algum ADM Abusando Do Poder? Reporte Com Print Imediatamente No Discord!",
	"{F08080}SCBR: Esta Gostando Do Servidor? Chame Seus Amigos Para Jogar Com Voce :D",
	"{F08080}SCBR: Viu Algum HACKER? Reporte-o Usando /report [ID] [MOTIVO]",
	"{F08080}SCBR: Street Of Caminhoneiros o Melhor Servidor de Caminhoes :D",
	"{F08080}SCBR: Voce Pode ler Nossas Regras Utilizando o Comando /regras !!",
	"{F08080}SCBR: Quer Saber os Desenvolvedores desta Gamemode use: /creditos",
	"{F08080}SCBR: Todos Direitos Rezervados a Equipe Street Of Caminhoneiros",
	"{F08080}SCBR: Voce sabia que Voce Pode ouvir a radio do servidor? Use /radio",
	"{F08080}SCBR: Esta Com Duvida Ou Perdido? Use /gps ou /ajuda"
};

LimparChat(playerid, lines);
enum Vehicle_DATA
{
	v_combustivel,
	Float:v_lataria,

	v_time_count,
	v_calc_comb,
}
new Vehicle[MAX_VEHICLES][Vehicle_DATA];
new
	mot,
	lu,
	alar,
	por,
	cap,
	porma,
	ob
;
new SVCarPLAYER[QntSlotCar][MAX_PLAYERS],SvCarCOR[QntSlotCar][MAX_PLAYERS];
new SVC_Localizar[MAX_PLAYERS],SvSelcCar[MAX_PLAYERS],pAceitar[MAX_PLAYERS][3],pTrancarCAR[MAX_VEHICLES];
//Empresaa
new CaminhaoEmpresa1[MAX_PLAYERS];
new CarregouEmpresa1[MAX_PLAYERS];
new CaminhaoEmpresa2[MAX_PLAYERS];
new CarregouEmpresa2[MAX_PLAYERS];
new CaminhaoEmpresa3[MAX_PLAYERS];
new CarregouEmpresa3[MAX_PLAYERS];
new CaminhaoEmpresa4[MAX_PLAYERS];
new CarregouEmpresa4[MAX_PLAYERS];
new CaminhaoEmpresa5[MAX_PLAYERS];
new CarregouEmpresa5[MAX_PLAYERS];
new CaminhaoEmpresa6[MAX_PLAYERS];
new CarregouEmpresa6[MAX_PLAYERS];
new CaminhaoEmpresa7[MAX_PLAYERS];
new CarregouEmpresa7[MAX_PLAYERS];
new CaminhaoEmpresa8[MAX_PLAYERS];
new CarregouEmpresa8[MAX_PLAYERS];
new CaminhaoEmpresa9[MAX_PLAYERS];
new CarregouEmpresa9[MAX_PLAYERS];

forward Logando(playerid);
forward Registrando(playerid);
forward kick(playerid);
forward Abastecendo(playerid);
forward VerificarPasta(pasta[]);
forward tpreso(playerid);
forward IsPlayerInRageOfPoint(Float:radi, playerid, Float:x, Float:y, Float:z);
forward Timer_Veiculos(playerid);
forward MensagensCC();
forward Real();
forward SetarLevel();
forward respawn();
forward Respawn();

static const ValorDosCarros[][] =//CONFS CARROS DA CONSE
{//  VALOR ,ID,Categoria, Modelo nome
    {10000000,411,0,"infernus"},
    {10000000,451,0,"turismo"},
    {162000,541,1,"Bullet"},
    {125000,429,3,"Banshee"},
    {73500,567,3,"Savanna"},
    {90000,402,1,"Buffalo"},
    {80000,559,1,"Jester"},
    {79500,560,1,"Sultan"},
    {82000,412,4,"Voodoo"},
    {70000,439,4,"Stallion"},
    {53780,549,4,"Tampa"},
    {65000,496,2,"Blista"},
    {70000,445,2,"Admiral"},
    {69500,401,2,"Bravura"},
    {51000,542,2,"Clover"},
    {85000,489,7,"Rancher"},
    {89000,554,7,"Yosemite"},
    {65000,422,6,"Bobcat"},
    {250000,522,11,"NRG-500"},
    {180000,461,11,"PCJ-600"},
    {150000,521,11,"FCR-900"},
    {50000,468,11,"Sanchez"}
};
static const ConfgTipoCarrs[][] ={//Nome das Categorias
	{"SuperEsportivo"},//0
	{"Esportivo"},//1
	{"Popular"},//2
	{"Conversivel"},//3
	{"Classico"},//4
	{"Corrida"},//5
	{"Picape"},//6
	{"Caminhonete"},//7
	{"Van"},//8
	{"Caminh�o"},//9
	{"Careta"},//10
	{"Moto"},//11
	{"VIP"}//12
};

static QntCarsConse = sizeof(ValorDosCarros);
static NomeDosCarros[][] ={
    "Landstalker", "Bravura", "Buffalo", "Linerunner", "Perrenial", "Sentinel",
    "Dumper", "Firetruck", "Trashmaster", "Stretch", "Manana", "Infernus",
    "Voodoo", "Pony", "Mule", "Cheetah", "Ambulance", "Leviathan", "Moonbeam",
    "Esperanto", "Taxi", "Washington", "Bobcat", "Whoopee", "BF Injection",
    "Hunter", "Premier", "Enforcer", "Securicar", "Banshee", "Predator", "Bus",
    "Rhino", "Barracks", "Hotknife", "Trailer", "Previon", "Coach", "Cabbie",
    "Stallion", "Rumpo", "RC Bandit", "Romero", "Packer", "Monster", "Admiral",
    "Squalo", "Seasparrow", "Pizzaboy", "Tram", "Trailer", "Turismo", "Speeder",
    "Reefer", "Tropic", "Flatbed", "Yankee", "Caddy", "Solair", "Berkley's RC Van",
    "Skimmer", "PCJ-600", "Faggio", "Freeway", "RC Baron", "RC Raider", "Glendale",
    "Oceanic","Sanchez", "Sparrow", "Patriot", "Quad", "Coastguard", "Dinghy",
    "Hermes", "Sabre", "Rustler", "ZR-350", "Walton", "Regina", "Comet", "BMX",
    "Burrito", "Camper", "Marquis", "Baggage", "Dozer", "Maverick", "News Chopper",
    "Rancher", "FBI Rancher", "Virgo", "Greenwood", "Jetmax", "Hotring", "Sandking",
    "Blista Compact", "Police Maverick", "Boxville", "Benson", "Mesa", "RC Goblin",
    "Hotring Racer A", "Hotring Racer B", "Bloodring Banger", "Rancher", "Super GT",
    "Elegant", "Journey", "Bike", "Mountain Bike", "Beagle", "Cropduster", "Stunt",
    "Tanker", "Roadtrain", "Nebula", "Majestic", "Buccaneer", "Shamal", "Hydra",
    "FCR-900", "NRG-500", "HPV1000", "Cement Truck", "Tow Truck", "Fortune",
    "Cadrona", "FBI Truck", "Willard", "Forklift", "Tractor", "Combine", "Feltzer",
    "Remington", "Slamvan", "Blade", "Freight", "Streak", "Vortex", "Vincent",
    "Bullet", "Clover", "Sadler", "Firetruck", "Hustler", "Intruder", "Primo",
    "Cargobob", "Tampa", "Sunrise", "Merit", "Utility", "Nevada", "Yosemite",
    "Windsor", "Monster", "Monster", "Uranus", "Jester", "Sultan", "Stratium",
    "Elegy", "Raindance", "RC Tiger", "Flash", "Tahoma", "Savanna", "Bandito",
    "Freight Flat", "Streak Carriage", "Kart", "Mower", "Dune", "Sweeper",
    "Broadway", "Tornado", "AT-400", "DFT-30", "Huntley", "Stafford", "BF-400",
    "News Van", "Tug", "Trailer", "Emperor", "Wayfarer", "Euros", "Hotdog", "Club",
    "Freight Box", "Trailer", "Andromada", "Dodo", "RC Cam", "Launch", "Police Car",
    "Police Car", "Police Car", "Police Ranger", "Picador", "S.W.A.T", "Alpha",
    "Phoenix", "Glendale", "Sadler", "Luggage", "Luggage", "Stairs", "Boxville",
    "Tiller", "Utility Trailer"
};
public OnFilterScriptInit(){
    AddStaticPickup(1274, 1, 2131.4729,-1149.9431,24.2078) ; //LOCAL CONSE - BY:CMD
    Create3DTextLabel("/conse", 0x00FCFCFF, 2131.4729,-1149.9431,24.2078, 30.0, 0);//LOCAL CONSE - BY:CMD
	return 1;
}

main()
{
	print("\n----------------------------------");
	print(" Gamemode Iniciada Com Sucesso ");
	print("----------------------------------\n");
}

AntiDeAMX()
{
    new a[][] = { "Unarmed (Fist)", "Brass K" };
    #pragma unused a
}

public OnGameModeInit()
{
    SetGameModeText("RPG Caminhoes v1.0");
    AntiDeAMX();
	ShowPlayerMarkers(0);
	DisableInteriorEnterExits();
	EnableStuntBonusForAll(0);
	SetNameTagDrawDistance(8.0);
	VerificarPasta("Contas");
	VerificarPasta("Banidos");
	VerificarPasta("BanidosIp");
	new t[3];
    gettime(t[0], t[1], t[2]);
    SetWorldTime(t[0]);
    new Float:x,Float:y,Float:z;
	for(new v=0;v<MAX_VEHICLES;v++)
	{
		if(GetVehiclePos(v,x,y,z))existe++;
	}
	for(new i = 0; i < MAX_VEHICLES; ++i)
	{
		Vehicle[i][v_combustivel] = 100;
	}
	for(new i = 0; i < MAX_PLAYERS; ++i)
	{
		SetTimerEx("Timer_Veiculos", 50, 1, "i", i);
	}
    //========================//
    SetTimer("Real", 60000, true);
	SetTimer("SetarLevel", 3600000, true);
	SetTimer("Respawn", 1800000, true);
	SetTimer("MensagensCC", 1200000, true);
	//========================//
	CidadePerigosa = GangZoneCreate(-2338.280761, -2395.477539, -2119.557373, -2222.591064);
	//========================//
	CreateActor(179, 295.1586,-40.2160,1001.5156,5.3909);//Loja de Armas 1
	CreateActor(179, 295.5544,-82.5298,1001.5156,4.0795);//Loja de Armas 2
	CreatePickup(1239, 1, -376.5482,-1443.6276,25.7266);
    CreatePickup(1239, 1, -72.2352,-1114.6338,1.0781);
    CreatePickup(1239, 1, 539.3470,-1291.5088,17.2422);
    CreatePickup(1239, 1, 1175.4042,-904.3761,43.3001);
    CreatePickup(1239, 1, 1253.3020,-1259.9574,13.2027);
    CreatePickup(1239, 1, 2458.6934,-2079.2932,13.5469);
    CreatePickup(1239, 1, 2169.0972,-2274.5005,13.3999);
    CreatePickup(1239, 1, 2761.6682,-2453.7708,13.5491);
    CreatePickup(1239, 1, 2181.3079,-1985.2875,13.5507);
    CreatePickup(1318, 1, 1369.0002,-1279.6810,13.5469);//Loja Arma 1
    CreatePickup(1318, 1, 2400.4355,-1981.9949,13.5469);//Loja Arma 2
    CreatePickup(1274, 1, 295.0589,-38.5141,1001.5156);//Comprar Arma Loja 1
    CreatePickup(1274, 1, 295.6003,-80.8117,1001.5156);//Comprar Arma Loja 2
    CreatePickup(1318, 1, 1928.5833,-1776.3274,13.5469);//Bar 1
    CreatePickup(1318, 1, 1000.6071,-919.9967,42.3281); //Bar 2
    CreatePickup(1318, 1, -78.3752,-1169.9047,2.1355); //Bar 3
    CreatePickup(1318, 1, -1562.5352,-2732.9260,48.7435); //bar 4
    CreatePickup(1318, 1, -1676.0560,432.3105,7.1797); //bar 5
    CreatePickup(1318, 1, 663.0432,1716.2684,7.1875); //bar 6
    CreatePickup(1318, 1, 2117.4294,896.7752,11.1797); //bar 7
    CreatePickup(1318, 1, 1383.2994,465.5362,20.1919); //bar 8
    CreatePickup(1318, 1, 661.3616,-573.3519,16.3359); //bar 9
    CreatePickup(1275, 1, 1530.2498,-1662.1816,6.2188); //Equipar Pol�cia Militar
    CreatePickup(1275, 1, -13.5890,-2489.5342,36.6484); //Equipar Policia Rodovi�ria
    CreatePickup(1275, 1, 34.1446,-2644.4697,40.7285); //Equipar GBM
    CreatePickup(1275, 1, -350.8861,-1048.5265,59.3376);//Equipar Gang 31AM
    CreatePickup(1275, 1, -91.3615,-1567.3782,2.6172);//Equipar GFM
    CreatePickup(1247, 1, 1545.3632,-1609.6223,13.3828);//Pckup Prender PM
    CreatePickup(1247, 1, -19.5060,-2476.1099,36.6484);// Pickuo Prender PRF
    Create3DTextLabel("{00FF00}Prisao Policia Militar\n{FFFFFF}Digite /prender",-1,1545.3632,-1609.6223,13.3828,10.0,0);
    Create3DTextLabel("{00FF00}Prisao Policia Rodoviaria\n{FFFFFF}Digite /prender",-1,-19.5060,-2476.1099,36.6484,10.0,0);
    Create3DTextLabel("{00FF00}Equipamentos Policia Militar\n{FFFFFF}Digite /equipar",-1,1530.2498,-1662.1816,6.2188,10.0,0);
    Create3DTextLabel("{00FF00}Equipamentos Policia Rodoviaria\n{FFFFFF}Digite /equipar",-1,-13.5890,-2489.5342,36.6484,10.0,0);
    Create3DTextLabel("{00FF00}Equipamentos GBN\n{FFFFFF}Digite /equipar",-1,34.1446,-2644.4697,40.7285,10.0,0);
    Create3DTextLabel("{00FF00}Equipamentos Gang 31AM\n{FFFFFF}Digite /equipar",-1,-350.8861,-1048.5265,59.3376,10.0,0);
    Create3DTextLabel("{00FF00}Equipamentos GFM\n{FFFFFF}Digite /equipar",-1,-91.3615,-1567.3782,2.6172,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Joao\n{FFFFFF}Clique F para entrar",-1,1928.5833,-1776.3274,13.5469,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Negao\n{FFFFFF}Clique F para entrar",-1,1000.6071,-919.9967,42.3281,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Beto\n{FFFFFF}Clique F para entrar",-1,-78.3752,-1169.9047,2.1355,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Vandinho\n{FFFFFF}Clique F para entrar",-1,-1562.5352,-2732.9260,48.7435,10.0,0);
	Create3DTextLabel("{00FF00}Bar da DonaMaria\n{FFFFFF}Clique F para entrar",-1,-1676.0560,432.3105,7.1797,10.0,0);
	Create3DTextLabel("{00FF00}Bar Copo Cheio\n{FFFFFF}Clique F para entrar",-1,663.0432,1716.2684,7.1875,10.0,0);
	Create3DTextLabel("{00FF00}Bar dos Otario\n{FFFFFF}Clique F para entrar",-1,2117.4294,896.7752,11.1797,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Vinicios\n{FFFFFF}Clique F para entrar",-1,1383.2994,465.5362,20.1919,10.0,0);
	Create3DTextLabel("{00FF00}Bar do Dias\n{FFFFFF}Clique F para entrar",-1,661.3616,-573.3519,16.3359,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,-376.5482,-1443.6276,25.7266,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,-72.2352,-1114.6338,1.0781,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,539.3470,-1291.5088,17.2422,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,1175.4042,-904.3761,43.3001,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,1253.3020,-1259.9574,13.2027,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,2458.6934,-2079.2932,13.5469,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,2169.0972,-2274.5005,13.3999,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,2761.6682,-2453.7708,13.5491,10.0,0);
	Create3DTextLabel("{00FF00}Area De Carregamento\n{FFFFFF}digite /carregar",-1,2181.3079,-1985.2875,13.5507,10.0,0);
	Create3DTextLabel("{00FF00}Loja De Armamentos\n{FFFFFF}Clique F para entrar",-1,2400.4355,-1981.9949,13.5469,10.0,0);
	Create3DTextLabel("{00FF00}Loja De Armamentos\n{FFFFFF}Clique F para entrar",-1,1369.0002,-1279.6810,13.5469,10.0,0);
	Create3DTextLabel("{00FF00}Lista De Armamentos\n{FFFFFF}Digite /comprar",-1,295.0589,-38.5141,1001.5156,10.0,0);
	Create3DTextLabel("{00FF00}Lista De Armamentos\n{FFFFFF}Digite /comprar",-1,295.6003,-80.8117,1001.5156,10.0,0);

	//Veiculos Servidor
	CreateVehicle(414,2184.2720,-2295.2729,13.6406,43.3140,1,1,false); //
	CreateVehicle(414,2181.4883,-2297.7961,13.6406,42.9334,1,1,false); //
	CreateVehicle(414,2178.4277,-2300.5037,13.6407,41.1162,1,1,false); //
	CreateVehicle(414,2175.2393,-2303.3525,13.6405,41.3260,1,1,false); //
	CreateVehicle(414,2171.8447,-2306.3003,13.6406,39.5657,1,1,false); //

	CreateVehicle(408,2190.8564,-1999.7375,14.1298,0.0719,1,1,false); //
	CreateVehicle(408,2186.4956,-1995.5480,14.0945,359.0646,1,1,false); //
	CreateVehicle(408,2181.7153,-1992.7034,14.0943,0.7921,1,1,false); //
	CreateVehicle(408,2165.0537,-1971.6671,14.1583,179.2397,1,1,false); //
	CreateVehicle(408,2160.5024,-1971.6852,14.1376,180.1539,1,1,false); //

	CreateVehicle(456,2448.9856,-2116.8164,13.7233,359.5114,1,1,false); //
	CreateVehicle(456,2456.6182,-2116.4656,13.7221,0.2171,1,1,false); //
	CreateVehicle(456,2464.7009,-2116.4221,13.7227,359.2211,1,1,false); //
	CreateVehicle(456,2472.5969,-2116.7776,13.7204,359.3186,1,1,false); //
	CreateVehicle(456,2479.9109,-2116.4771,13.7214,2.0421,1,1,false); //

	CreateVehicle(498,2748.2168,-2459.0432,13.7152,271.6696,1,1,false); //
	CreateVehicle(498,2748.3325,-2464.3938,13.7179,271.1312,1,1,false); //
	CreateVehicle(498,2748.5334,-2470.1201,13.7158,271.9573,1,1,false); //
	CreateVehicle(498,2742.5261,-2490.7803,13.7217,178.6448,1,1,false); //
	CreateVehicle(498,2736.4192,-2491.1912,13.7223,181.8169,1,1,false); //

	CreateVehicle(455,1238.9412,-1266.3669,13.8679,269.0327,1,1,false); //
	CreateVehicle(455,1278.0270,-1260.3048,14.1256,90.8746,1,1,false); //
	CreateVehicle(455,1278.1003,-1254.3883,14.3726,90.3992,1,1,false); //
	CreateVehicle(455,1277.8998,-1247.5449,14.5362,91.5520,1,1,false); //
	CreateVehicle(455,1244.8062,-1257.8027,13.6120,2.4396,1,1,false); //

	CreateVehicle(609,1171.9623,-881.8199,43.3873,189.2395,1,1,false); //
	CreateVehicle(609,1177.1833,-881.0721,43.2900,187.4706,1,1,false); //
	CreateVehicle(609,1182.3783,-880.2137,43.2366,187.9073,1,1,false); //
	CreateVehicle(609,1187.6436,-879.3961,43.1811,188.2463,1,1,false); //
	CreateVehicle(609,1193.0531,-878.6363,43.1227,188.3235,1,1,false); //

	CreateVehicle(443,503.3498,-1299.8542,17.8766,309.3251,1,1,false); //
	CreateVehicle(443,506.2212,-1303.1803,17.8840,307.3687,1,1,false); //
	CreateVehicle(443,570.9598,-1298.9551,17.8815,11.7696,1,1,false); //
	CreateVehicle(443,567.2433,-1283.2130,17.8788,13.8740,1,1,false); //
	CreateVehicle(443,561.1658,-1284.9059,17.8809,13.1316,1,1,false); //

	CreateVehicle(482,-65.4678,-1145.7147,1.1950,334.2726,1,1,false); //
	CreateVehicle(482,-61.8206,-1147.3842,1.1937,335.7636,1,1,false); //
	CreateVehicle(482,-58.3011,-1149.0151,1.1956,336.8265,1,1,false); //
	CreateVehicle(482,-54.3811,-1150.8195,1.1902,338.2350,1,1,false); //
	CreateVehicle(482,-49.8038,-1152.9160,1.2024,340.1774,1,1,false); //

	CreateVehicle(478,-380.2834,-1452.6761,25.7141,358.9916,1,1,false); //
	CreateVehicle(478,-376.4223,-1452.8834,25.7188,359.1227,1,1,false); //
	CreateVehicle(478,-371.9445,-1452.8251,25.7167,359.4661,1,1,false); //
	CreateVehicle(478,-368.2437,-1441.3279,25.7176,89.0044,1,1,false); //
	CreateVehicle(478,-368.3360,-1437.5647,25.7177,90.2573,1,1,false); //

	return 1;
}

public OnGameModeExit()
{
	DOF2_Exit();
	return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
	return 1;
}

public OnPlayerConnect(playerid)
{
    //============================================================================================
    format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
	if(!DOF2_FileExists(arquivo))
	{
	    Limparchat(playerid);
        SendClientMessage(playerid,-1,"{1E90FF}SCBR: Aguarde enquanto o Servidor e Carregado...");
        SetTimerEx("Registrando", 7000, false, "i", playerid);
		return 1;
	}
	Limparchat(playerid);
	SetTimerEx("Logando", 7000, false, "i", playerid);
    SendClientMessage(playerid,-1,"{1E90FF}SCBR: Aguarde enquanto o Servidor e Carregado...");
	//============================================================================================
	format(arquivo,sizeof(arquivo),"Banidos/%s.txt",PlayerName(playerid));
    if(DOF2_FileExists(arquivo))
	{
		format(String,sizeof(String),"{FF0000}  CONTA BANIDA  \n{FF0000}Nome:{FFFFFF} %s	\n\n{FF0000}Admin:{FFFFFF} %s	\n\n{FF0000}Motivo:{FFFFFF} %s	\n\n{FF0000}Tempo:{FFFFFF} Permanente	\n\n",PlayerName(playerid), DOF2_GetString(arquivo,"ADM"),DOF2_GetString(arquivo,"Motivo"));
		ShowPlayerDialog(playerid,DIALOG_BANIDO,DIALOG_STYLE_MSGBOX,"",String,"Sair","");
		SetTimerEx("kick", 2000, false, "i", playerid);
		return 1;
	}
    new ip[25];
	GetPlayerIp(playerid,ip,sizeof(ip));
	format(arquivo,sizeof(arquivo),"BanidosIp/%s.txt",ip);
	if(DOF2_FileExists(arquivo))
	{
		format(String,sizeof(String),"{FF0000}  CONTA BANIDA  \n{FF0000}Nome:{FFFFFF} %s	\n\n{FF0000}Admin:{FFFFFF} %s	\n\n{FF0000}Motivo:{FFFFFF} %s		\n\n{FF0000}Tempo:{FFFFFF} Permanente	\n\n",PlayerName(playerid), DOF2_GetString(arquivo,"ADM"),DOF2_GetString(arquivo,"Motivo"));
		ShowPlayerDialog(playerid,DIALOG_BANIDO,DIALOG_STYLE_MSGBOX,"",String,"Sair","");
        SetTimerEx("kick", 2000, false, "i", playerid);
		return 1;
	}
	//============================================================================================
	//Icones Empresas
    SetPlayerMapIcon(playerid, 1, -376.5482,-1443.6276,25.7266, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 2, -72.2352,-1114.6338,1.0781, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 3, 539.3470,-1291.5088,17.2422, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 4, 1175.4042,-904.3761,43.3001, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 5, 1253.3020,-1259.9574,13.2027, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 6, 2458.6934,-2079.2932,13.5469, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 7, 2169.0972,-2274.5005,13.3999, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 8, 2761.6682,-2453.7708,13.5491, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 9, 2181.3079,-1985.2875,13.5507, 51, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 10, 1369.0002,-1279.6810,13.5469, 18, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 11, 2400.4355,-1981.9949,13.5469, 18, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 12, 1928.5833,-1776.3274,13.5469, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 13, 1000.6071,-919.9967,42.3281, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 14, -78.3752,-1169.9047,2.1355, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 15, -1562.5352,-2732.9260,48.7435, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 16, -1676.0560,432.3105,7.1797, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 17, 663.0432,1716.2684,7.1875, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 18, 2117.4294,896.7752,11.1797, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 19, 1383.2994,465.5362,20.1919, 49, 0, MAPICON_LOCAL);
    SetPlayerMapIcon(playerid, 20, 661.3616,-573.3519,16.3359, 49, 0, MAPICON_LOCAL);
    //====================================//
    PlayerInfo[playerid][Algemado] = false;
	PlayerInfo[playerid][Arrastado] = 0;
	//====================================//
	GangZoneShowForPlayer(playerid, CidadePerigosa, COR_VERMELHO);
	//====================================//
	return 1;
}
public OnPlayerDisconnect(playerid, reason)
{
    SalvarDados(playerid);
    PlayerInfo[playerid][Trabalhando] = false;
	DisablePlayerCheckpoint(playerid);
	SVC_Localizar[playerid] = 0;
    for (new i = 0; i < QntSlotCar; i++){
	    DestroyVehicle(SVCarPLAYER[i][playerid]);
	    SVCarPLAYER[i][playerid] = 0;
    }
	return 1;
}

public OnPlayerSpawn(playerid)
{
    format(arquivo, sizeof(arquivo), "Presos/%s.txt", PlayerName(playerid));
	new tempo = DOF2_GetInt(arquivo, "Tempo Preso");
 	if(tempo > 0)
 	{
		SendClientMessage(playerid,-1,"{FF0000} Voce nao cumpriu sua pena por isso voltou a cadeia");
        SetPlayerPos(playerid, 196.9844, 162.0234, 1002.6875);
        SetPlayerInterior(playerid,3);
        SetTimerEx("tpreso",tempo,false,"i",playerid);
	}
	if(PlayerInfo[playerid][Org] == 1)//Policia Militar
	{
		SetPlayerPos(playerid, 1525.7792,-1678.1709,5.8906);
		SetPlayerColor(playerid, BRANCO);
	}
	if(PlayerInfo[playerid][Org] == 2)//Policia Rodoviaria
	{
		SetPlayerPos(playerid, -9.4711,-2496.3442,36.6484);
		SetPlayerColor(playerid, BRANCO);
	}
	if(PlayerInfo[playerid][Org] == 3)//GBM
	{
		SetPlayerPos(playerid, 33.2523,-2649.9324,40.7285);
		SetPlayerColor(playerid, BRANCO);
	}
	if(PlayerInfo[playerid][Org] == 4)//Gang 31AM
	{
		SetPlayerPos(playerid, -347.5176,-1046.3621,59.8125);
		SetPlayerColor(playerid, BRANCO);
	}
	if(PlayerInfo[playerid][Org] == 5)//GFM
	{
		SetPlayerPos(playerid, -88.8637,-1565.2402,3.0043);
		SetPlayerColor(playerid, BRANCO);
	}
	return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
	return 1;
}

public OnVehicleSpawn(vehicleid)
{
    new motor,farois,alarme,doors,bonnet,boot,obj;
    GetVehicleParamsEx(GetPlayerVehicleID(vehicleid),motor,farois,alarme,doors,bonnet,boot,obj);
    SetVehicleParamsEx(GetPlayerVehicleID(vehicleid),farois,0,alarme,0,bonnet,boot,obj);
	return 1;
}

public OnVehicleDeath(vehicleid, killerid)
{
	return 1;
}
public OnPlayerCommandPerformed(playerid, cmdtext[], success)
{
   if(!success) SendClientMessage(playerid, -1, "{FF0000}[ERRO] Comando Inexistente Use: /ajuda para duvidas.");
   return 1;
}
public OnPlayerText(playerid, text[])
{
    new string[256];
	format(string, sizeof(string), "{FFFFFF}%s{FFFFFF} diz: {FFFFFF}%s", PlayerName(playerid), text);
	SendClientMessageInRange(30.0, playerid, string, -1,-1,-1,-1,-1);
	SetPlayerChatBubble(playerid, text, -1, 35.0, 10000);
	return 0;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
	if(strcmp(cmdtext, "/entrar", true) == 0)
	{
 		if (IsPlayerInRangeOfPoint(playerid, 2.0, 2400.4355,-1981.9949,13.5469))
	 	{
	   		SetPlayerInterior(playerid, 1);
	     	SetPlayerPos(playerid, 286.148986,-40.644397,1001.515625);
	     	GameTextForPlayer(playerid, "Loja de Armas", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 1369.0002,-1279.6810,13.5469))
	 	{
	   		SetPlayerInterior(playerid, 4);
	     	SetPlayerPos(playerid, 285.8499,-86.7813,1001.5229);
	     	GameTextForPlayer(playerid, "Loja de Armas", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 1928.5833,-1776.3274,13.5469))
	 	{
	   		SetPlayerInterior(playerid, 18);
	     	SetPlayerPos(playerid, -227.027999,1401.229980,27.765625);
	     	GameTextForPlayer(playerid, "Bar do Joao", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 1000.6071,-919.9967,42.3281))
	 	{
	   		SetPlayerInterior(playerid, 5);
	     	SetPlayerPos(playerid, 454.973937,-110.104995,1000.077209);
	     	GameTextForPlayer(playerid, "Bar do Negao", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, -78.3752,-1169.9047,2.1355))
	 	{
	   		SetPlayerInterior(playerid, 11);
	     	SetPlayerPos(playerid, 501.980987,-69.150199,998.757812);
	     	GameTextForPlayer(playerid, "Bar do Beto", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, -1562.5352,-2732.9260,48.7435))
	 	{
	   		SetPlayerInterior(playerid, 4);
	     	SetPlayerPos(playerid, 457.304748,-88.428497,999.554687);
	     	GameTextForPlayer(playerid, "Bar do Vandinho", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, -1676.0560,432.3105,7.1797))
	 	{
	   		SetPlayerInterior(playerid, 6);
	     	SetPlayerPos(playerid, 435.271331,-80.958938,999.554687);
	     	GameTextForPlayer(playerid, "Bar da DonaMaria", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 663.0432,1716.2684,7.1875))
	 	{
	   		SetPlayerInterior(playerid, 1);
	     	SetPlayerPos(playerid, 452.489990,-18.179698,1001.132812);
	     	GameTextForPlayer(playerid, "Bar Copo Cheio", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 1383.2994,465.5362,20.1919))
	 	{
	   		SetPlayerInterior(playerid, 6);
	     	SetPlayerPos(playerid, 761.412963,1440.191650,1102.703125);
	     	GameTextForPlayer(playerid, "Bar do Vinicios", 2000, 1);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 661.3616,-573.3519,16.3359))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 663.836242,-575.605407,16.343263);
	     	GameTextForPlayer(playerid, "Bar do Dias", 2000, 1);
		}
	}
	if(strcmp(cmdtext, "/sair", true) == 0)
	{
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 285.8499,-86.7813,1001.5229))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 1369.0002,-1279.6810,13.5469);
		}
 		if (IsPlayerInRangeOfPoint(playerid, 2.0, 286.148986,-40.644397,1001.515625))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 2400.4355,-1981.9949,13.5469);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, -227.027999,1401.229980,27.765625))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 1928.5833,-1776.3274,13.5469);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 454.973937,-110.104995,1000.077209))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 1000.6071,-919.9967,42.3281);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 501.980987,-69.150199,998.757812))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, -78.3752,-1169.9047,2.1355);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 457.304748,-88.428497,999.554687))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, -1562.5352,-2732.9260,48.7435);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 435.271331,-80.958938,999.554687))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, -1676.0560,432.3105,7.1797);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 452.489990,-18.179698,1001.132812))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 663.0432,1716.2684,7.1875);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 681.557861,-455.680053,-25.609874))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 2117.4294,896.7752,11.1797);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 761.412963,1440.191650,1102.703125))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 1383.2994,465.5362,20.1919);
		}
		if (IsPlayerInRangeOfPoint(playerid, 2.0, 663.836242,-575.605407,16.343263))
	 	{
	   		SetPlayerInterior(playerid, 0);
	     	SetPlayerPos(playerid, 661.3616,-573.3519,16.3359);
		}
	}
	new string[128];
    if (strcmp("/conse", cmdtext, true) == 0){
//	    if(!IsPlayerInRangeOfPoint(playerid,2.0,2131.4729,-1149.9431,24.2078)) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao esta no local!");
        new StrChatADM[3500];
		strcat(StrChatADM, "{33CC33}Modelo\t\tValor\t\tCategoria\n");
		strcat(StrChatADM, "{FFFFFF}");
		for(new i = 0; i < QntCarsConse; i++){
			format(string, sizeof(string), "%s(%i)\tR$%i\t%s\n",ValorDosCarros[i][3],ValorDosCarros[i][1],ValorDosCarros[i][0],ConfgTipoCarrs[ValorDosCarros[i][2]][0]);
			strcat(StrChatADM, string);
		}
		ShowPlayerDialog(playerid, Dial_conseTX, DIALOG_STYLE_LIST, "{FF0000}Concession�ria de veiculos", StrChatADM, "Comprar", "Cancelar");
       	return 1;
	}
    if (strcmp("/menucar", cmdtext, true) == 0){
		new StrChatADM[500];
        strcat(StrChatADM, "{FF6347}[1]{FFFFFF} - Estacionar\n");
		strcat(StrChatADM, "{FF6347}[2]{FFFFFF} - Pegar o veiculo\n");
		strcat(StrChatADM, "{FF6347}[3]{FFFFFF} - Localizar\n");
		strcat(StrChatADM, "{FF6347}[4]{FFFFFF} - Remover\n");
		strcat(StrChatADM, "{FF6347}[5]{FFFFFF} - Vender\n");
		strcat(StrChatADM, "{FF6347}[6]{FFFFFF} - Vender para um jogador\n");
		strcat(StrChatADM, "{FF6347}[7]{FFFFFF} - Aceitar a compra de um veiculo\n");
		strcat(StrChatADM, "{FF6347}[8]{FFFFFF} - Trancar\n");
		strcat(StrChatADM, "{FF6347}[9]{FFFFFF} - Destrancar\n");
		ShowPlayerDialog(playerid, Diag_Menu_Car, DIALOG_STYLE_INPUT, "Menu Carros", StrChatADM, "Ok", "Cancelar");
        return 1;
    }
	return 0;
}

public OnPlayerEnterVehicle(playerid, vehicleid)
{
	if(pTrancarCAR[vehicleid] == 1){
	SendClientMessage(playerid, 0xFF0000FF, "Este veiculo esta trancado!");
	new Float:Pos[3];
	GetPlayerPos(playerid, Pos[0], Pos[1], Pos[2]);
	SetPlayerPos(playerid, Pos[0], Pos[1], Pos[2]);
    return 1;
}

public OnPlayerExitVehicle(playerid, vehicleid)
{
	return 1;
}

public OnPlayerStateChange(playerid, newstate, oldstate)
{
    new motor,farois,alarme,doors,bonnet,boot,obj;
    if(IsPlayerInAnyVehicle(playerid))
	{
	    GetVehicleParamsEx(GetPlayerVehicleID(playerid),motor,farois,alarme,doors,bonnet,boot,obj);
	    SetVehicleParamsEx(GetPlayerVehicleID(playerid),farois,0,alarme,0,bonnet,boot,obj);
	  	SendClientMessage(playerid, -1, "{1E90FF}[SCBR] Para ligar e desligar seu veiculo use /motor");
  	}
	return 1;
}

public OnPlayerEnterCheckpoint(playerid)
{
	if(SVC_Localizar[playerid] == 1){
    	DisablePlayerCheckpoint(playerid);
    	SendClientMessage(playerid, 0xFF0000FF, "Voce chegou no local do seu veiculo!");
    }
    if(CaminhaoEmpresa1[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa1[playerid] = false;
    	SetTimerEx("DescarregarEmpresa1", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa2[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa2[playerid] = false;
    	SetTimerEx("DescarregarEmpresa2", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa3[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa3[playerid] = false;
    	SetTimerEx("DescarregarEmpresa3", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa4[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa4[playerid] = false;
    	SetTimerEx("DescarregarEmpresa4", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa5[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa5[playerid] = false;
    	SetTimerEx("DescarregarEmpresa5", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa6[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa6[playerid] = false;
    	SetTimerEx("DescarregarEmpresa6", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa7[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa7[playerid] = false;
    	SetTimerEx("DescarregarEmpresa7", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa8[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa8[playerid] = false;
    	SetTimerEx("DescarregarEmpresa8", 5000, false, "d", playerid);
   	}
    if(CaminhaoEmpresa9[playerid])
    {
  		DisablePlayerCheckpoint(playerid);
	    GameTextForPlayer(playerid, "Descarregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
      	TogglePlayerControllable(playerid, 0);
      	CaminhaoEmpresa9[playerid] = false;
    	SetTimerEx("DescarregarEmpresa9", 5000, false, "d", playerid);
   	}
	return 1;
}

public OnPlayerLeaveCheckpoint(playerid)
{
	return 1;
}

public OnPlayerEnterRaceCheckpoint(playerid)
{
	return 1;
}

public OnPlayerLeaveRaceCheckpoint(playerid)
{
	return 1;
}

public OnRconCommand(cmd[])
{
	return 1;
}

public OnPlayerRequestSpawn(playerid)
{
	return 1;
}

public OnObjectMoved(objectid)
{
	return 1;
}

public OnPlayerObjectMoved(playerid, objectid)
{
	return 1;
}

public OnPlayerPickUpPickup(playerid, pickupid)
{
	return 1;
}

public OnVehicleMod(playerid, vehicleid, componentid)
{
	return 1;
}

public OnVehiclePaintjob(playerid, vehicleid, paintjobid)
{
	return 1;
}

public OnVehicleRespray(playerid, vehicleid, color1, color2)
{
	return 1;
}

public OnPlayerSelectedMenuRow(playerid, row)
{
	return 1;
}

public OnPlayerExitedMenu(playerid)
{
	return 1;
}

public OnPlayerInteriorChange(playerid, newinteriorid, oldinteriorid)
{
	return 1;
}

public OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
	if((newkeys==KEY_SECONDARY_ATTACK))
    {
    	OnPlayerCommandText(playerid,"/entrar");
    	OnPlayerCommandText(playerid,"/sair");
	}
	return 1;
}

public OnRconLoginAttempt(ip[], password[], success)
{
    new name[MAX_PLAYER_NAME],pip[16];
 	for(new i=0; i<MAX_PLAYERS; i++)
  	{
   		GetPlayerIp(i, pip, sizeof(pip));
     	if(!strcmp(ip, pip, true))
      	{
       		GetPlayerName(i, name, sizeof(name));
         	if(strcmp(name,"Ribeiro_Scrit",false) && strcmp(name,"cailon",false))
          	{
           		SendClientMessage(i,-1," {FF2400}[RCON] Voc� n�o esta autorizado a logar na rcon.");
             	Kick(i);
           	}
		}
	}
	return 1;
}

public OnPlayerUpdate(playerid)
{
    new Float:x,Float:y,Float:z;
	if(PlayerInfo[playerid][Algemado] == true)
	{
		SetPlayerPos(playerid,x,y,z);
	}
	return 1;
}

public OnPlayerStreamIn(playerid, forplayerid)
{
	return 1;
}

public OnPlayerStreamOut(playerid, forplayerid)
{
	return 1;
}

public OnVehicleStreamIn(vehicleid, forplayerid)
{
	return 1;
}

public OnVehicleStreamOut(vehicleid, forplayerid)
{
	return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_BANIDO)
	{
		if(response)
		{
            Kick(playerid);
		}
	}
	if(dialogid == DIALOG_CONVITE)
	{
		if (response)
		{
			PlayerInfo[playerid][Org] = PlayerInfo[playerid][convite];
			PlayerInfo[playerid][Cargo] = 1;
			SalvarDados(playerid);
			format(String,sizeof(String),"%s e o novo membro da %s",PlayerName(playerid),NomeOrg(playerid));
			MsgOrg(playerid,String);
			SendClientMessage(playerid,-1,String);
			PlayerInfo[playerid][convite] = 0;
		}
		if(!response)
		{
			SendClientMessage(playerid,-1,"{FF0000}[Convite] Voce recusou o convite");
		}
	}
    if(dialogid == DIALOG_REGISTRO)
    {
        if(response)
        {
            if(strlen(inputtext) >= 5 && strlen(inputtext) <= 10)
            {
                format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
	            DOF2_CreateFile(arquivo);
	   			DOF2_SetString(arquivo, "Senha", inputtext);
	            DOF2_SetInt(arquivo, "Dinheiro", 0);
	            DOF2_SetInt(arquivo, "Skin", 0);
	            DOF2_SetInt(arquivo, "Admin", 0);
	            DOF2_SetInt(arquivo, "Level", 0);
	            DOF2_SetInt(arquivo, "Org", 0);
	            DOF2_SetInt(arquivo, "Cargo", 0);
	            DOF2_WriteFile();
				GivePlayerMoney(playerid, 1000);
	            ShowPlayerDialog(playerid, DIALOG_SEXO, DIALOG_STYLE_MSGBOX, "Sexo", "{FFFFFF}Escolha seu Sexo para Jogar", "Homem", "Mulher");
			}
			else
			{
       			new string[256];
			    SendClientMessage(playerid, -1, "{FF0000}[ERRO] Digite Caracteres entre 5 a 10.");
			    format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) ao Servidor\nNome: {708090}%s\n{FFFFFF}Conta: {FF0000}Nao Registrada\n{FFFFFF}Digite sua senha de Registro", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_REGISTRO, DIALOG_STYLE_PASSWORD, "Registro", string, "Registrar", "Cancelar");
			}
		}
		else
		{
		    Kick(playerid);
		}
	}
	if(dialogid == DIALOG_LOGIN)
	{
	    if(response)
	    {
	        if(!strlen(inputtext))
	        {
	            new string[256];
	            format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
	            return 1;
			}
			format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
			if(strcmp(inputtext, DOF2_GetString(arquivo, "Senha"), true))
            {
             	new string[256];
	            format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
				SendClientMessage(playerid, -1, "{FF0000}[ERRO] Senha Incorreta Digite Novamente");
			}
			else
			{
	   			PlayerInfo[playerid][Dinheiro] = DOF2_GetInt(arquivo, "Dinheiro");
	      		PlayerInfo[playerid][Skin] = DOF2_GetInt(arquivo, "Skin");
	        	PlayerInfo[playerid][Admin] = DOF2_GetInt(arquivo, "Admin");
	        	PlayerInfo[playerid][Sexo] = DOF2_GetInt(arquivo, "Sexo");
	        	PlayerInfo[playerid][Level] = DOF2_GetInt(arquivo, "Level");
	        	PlayerInfo[playerid][Org] = DOF2_GetInt(arquivo, "Org");
	        	PlayerInfo[playerid][Cargo] = DOF2_GetInt(arquivo, "Cargo");
	        	GivePlayerMoney(playerid, PlayerInfo[playerid][Dinheiro]);
	        	TogglePlayerSpectating(playerid, false);
	       		StopAudioStreamForPlayer(playerid);
			    SendClientMessage(playerid, -1, "{00FF00}======================================================");
			    SendClientMessage(playerid, -1, "{FFFFFF} Bem Vindo(a) Novamente ao Street Of Caminhoneiro");
			    SendClientMessage(playerid, -1, "{FFFFFF} Deseja Voltar para Sua Ultima Posi��o Use: /continuar");
			    SendClientMessage(playerid, -1, "{00FF00}====================================================");
			    SetSpawnInfo(playerid, 0, PlayerInfo[playerid][Skin], 1685.4121,-2333.7273,13.5469, 0, 0, 0, 0, 0, 0, 0);
				SpawnPlayer(playerid);
			}
		}
		else
		{
			Kick(playerid);
		}
	}
	if(dialogid == DIALOG_SEXO)
	{
		if(response)
		{
  			PlayerInfo[playerid][Sexo] = 1;
        	ClearAnimations(playerid);
   			SetPlayerSkin(playerid, 37);
   			StopAudioStreamForPlayer(playerid);
			IrAviao(playerid);
		}
 		else
		{
  			PlayerInfo[playerid][Sexo] = 2;
        	ClearAnimations(playerid);
   			SetPlayerSkin(playerid, 38);
   			StopAudioStreamForPlayer(playerid);
			IrAviao(playerid);
		}
	}
	if(dialogid == DIALOG_ARMAS)
	{
		if(response)
		{
			if(listitem == 0)
			{
				if(GetPlayerMoney(playerid) < 30000) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao Possui Dinheiro Suficiente");
				{
					GivePlayerWeapon(playerid, 22, 100);
					SendClientMessage(playerid, -1, "{FF0000}[LOJA] Voce Adquiriu uma Pistola 9mm com 100 Balas");
				}
			}
 			if(listitem == 1)
			{
				if(GetPlayerMoney(playerid) < 50000) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao Possui Dinheiro Suficiente");
				{
					GivePlayerWeapon(playerid, 23, 100);
					SendClientMessage(playerid, -1, "{FF0000}[LOJA] Voce Adquiriu uma Pistola Silenced 9mm com 100 Balas");
				}
			}
			if(listitem == 2)
			{
				if(GetPlayerMoney(playerid) < 70000) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao Possui Dinheiro Suficiente");
				{
					GivePlayerWeapon(playerid, 24, 100);
					SendClientMessage(playerid, -1, "{FF0000}[LOJA] Voce Adquiriu uma Pistola Desert Eagle com 100 Balas");
				}
			}
			if(listitem == 3)
			{
				if(GetPlayerMoney(playerid) < 2000) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao Possui Dinheiro Suficiente");
				{
					GivePlayerWeapon(playerid, 8, 100);
					SendClientMessage(playerid, -1, "{FF0000}[LOJA] Voce Adquiriu uma Katana por R$2000");
				}
			}
			if(listitem == 4)
			{
				if(GetPlayerMoney(playerid) < 50) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao Possui Dinheiro Suficiente");
				{
					GivePlayerWeapon(playerid, 4, 100);
					SendClientMessage(playerid, -1, "{FF0000}[LOJA] Voce Adquiriu uma Faca por R$50");
				}
			}
		}
	}
	if(dialogid == DIALOG_PM)
	{
		if(response)
		{
			if(listitem == 0)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 281);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
	                GivePlayerWeapon(playerid, 31, 1000);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			    	ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 307);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
	                GivePlayerWeapon(playerid, 31, 1000);
				}
			}
        	if(listitem == 1)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)//Homem
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 284);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
				}
				if(PlayerInfo[playerid][Sexo] == 2)//Mulher
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 307);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
				}
			}
			if(listitem == 2)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 303);
					SetPlayerColor(playerid, COR_AZUL);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 309);
					SetPlayerColor(playerid, COR_AZUL);
				}
			}
			if(listitem == 3)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, PlayerInfo[playerid][Skin]);
					SetPlayerColor(playerid, BRANCO);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, PlayerInfo[playerid][Skin]);
					SetPlayerColor(playerid, BRANCO);
				}
			}
		}
	}
	if(dialogid == DIALOG_PRF)
	{
		if(response)
		{
			if(listitem == 0)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 280);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
	                GivePlayerWeapon(playerid, 31, 1000);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 306);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
	                GivePlayerWeapon(playerid, 31, 1000);
				}
			}
        	if(listitem == 1)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 284);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 306);
					SetPlayerColor(playerid, COR_AZUL);
					GivePlayerWeapon(playerid, 3, 100);
	                GivePlayerWeapon(playerid, 24, 1000);
				}
			}
			if(listitem == 2)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 303);
					SetPlayerColor(playerid, COR_AZUL);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, 309);
					SetPlayerColor(playerid, COR_AZUL);
				}
			}
			if(listitem == 3)
			{
			    if(PlayerInfo[playerid][Sexo] == 1)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, PlayerInfo[playerid][Skin]);
					SetPlayerColor(playerid, BRANCO);
				}
				if(PlayerInfo[playerid][Sexo] == 2)
			    {
			        ResetPlayerWeapons(playerid);
			        SetPlayerSkin(playerid, PlayerInfo[playerid][Skin]);
					SetPlayerColor(playerid, BRANCO);
				}
			}
		}
	}
	if(dialogid == DIALOG_AJUDA)
	{
		if(response)
		{
			if(listitem == 0)
			{
				strcat(MEGAString, "{CFCFCF}|__________ Servidor Comandos __________|\n");
				strcat(MEGAString, "{CFCFCF}/pagar /dance /gritar /radio\n");
				strcat(MEGAString, "{CFCFCF}/anuncio /sms /eu /comprar /n(chat noob)\n");
				strcat(MEGAString, "{CFCFCF}/render /deitar /punheta\n");
        		ShowPlayerDialog(playerid, DIALOG_CMD1, DIALOG_STYLE_MSGBOX, "Ajuda Comandos", MEGAString, "Sair", "Sair");
			}
            if(listitem == 1)
			{
			    strcat(MEGAString, "{CFCFCF}|__________ Empresa Comandos __________|\n");
				strcat(MEGAString, "{CFCFCF}/comprar\n");
        		ShowPlayerDialog(playerid, DIALOG_CMD2, DIALOG_STYLE_MSGBOX, "Ajuda Comandos", MEGAString, "Sair", "Sair");
			}
          	if(listitem == 2)
			{
			    strcat(MEGAString, "{CFCFCF}|__________ Casas Comandos __________|\n");
				strcat(MEGAString, "{CFCFCF}/comprarcasa /vendercasa\n");
        		ShowPlayerDialog(playerid, DIALOG_CMD3, DIALOG_STYLE_MSGBOX, "Ajuda Comandos", MEGAString, "Sair", "Sair");
			}
            if(listitem == 3)
			{
			    if(PlayerInfo[playerid][Org] == 1 || PlayerInfo[playerid][Org] == 2)
			    {
			        strcat(MEGAString, "{CFCFCF}|__________ Corporacao Comandos __________|\n");
					strcat(MEGAString, "{CFCFCF}/convidar /promover /demitir /algemar\n");
					strcat(MEGAString, "{CFCFCF}/desalgemar /prender /r(radio) /d(copom)\n");
	        		ShowPlayerDialog(playerid, DIALOG_CMD4, DIALOG_STYLE_MSGBOX, "Ajuda Comandos", MEGAString, "Sair", "Sair");
				}
			}
		}
	}
	if(dialogid == Diag_Menu_Car){
			    if(strcmp(inputtext, "1", true) == 0){
			        if(!IsPlayerInAnyVehicle(playerid)) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao esta em um veiculo!");
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo para ser estacionado\n\n");
					path = SaveCarNomePlay(playerid);
					strcat(StrMV, "\n{FF0000}Seus Carros comprados:\n\n");
					for(new i = 0; i < QntSlotCar; i++){
					        new DefCarSlot = GetVehicleModel(SVCarPLAYER[i][playerid]);
					        if(DefCarSlot >= 400){
								format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i)\n",i, NomeDosCarros[DefCarSlot-400],DefCarSlot);
								strcat(StrMV, FtrMV);
							}
					}
					strcat(StrMV, "\n{FF0000}Seus Carros Salvos:\n\n");
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i)\n",i, NomeDosCarros[SCCarid-400],SCCarid);
							strcat(StrMV, FtrMV);
						}
					}
			        ShowPlayerDialog(playerid, NIDConseCarsC1, DIALOG_STYLE_INPUT, "Estacionar Veiculo", StrMV, "OK", "Cancelar");
			    }
			    else if(strcmp(inputtext, "2", true) == 0){
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo a ser Spawnado\n\n");
					path = SaveCarNomePlay(playerid);
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i)\n",i, NomeDosCarros[SCCarid-400],SCCarid);
							strcat(StrMV, FtrMV);
						}
					}
	                ShowPlayerDialog(playerid, NIDConseCarsC3, DIALOG_STYLE_INPUT, "Spawnar Veiculo", StrMV, "OK", "Cancelar");
			        return 1;
			    }
			    else if(strcmp(inputtext, "3", true) == 0){
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo a ser localizado\n\n");
					path = SaveCarNomePlay(playerid);
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i)\n",i, NomeDosCarros[SCCarid-400],SCCarid);
							strcat(StrMV, FtrMV);
						}
					}
			        ShowPlayerDialog(playerid, NIDConseCarsC2, DIALOG_STYLE_INPUT, "Localizar Veiculo", StrMV, "OK", "Cancelar");
			    }
			    else if(strcmp(inputtext, "4", true) == 0){
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo para ser removido\n\n");
					path = SaveCarNomePlay(playerid);
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i)\n",i, NomeDosCarros[SCCarid-400],SCCarid);
							strcat(StrMV, FtrMV);
						}
					}
	                ShowPlayerDialog(playerid, NIDConseCarsC5, DIALOG_STYLE_INPUT, "Remover Veiculo", StrMV, "OK", "Cancelar");
			        return 1;
			    }
			    else if(strcmp(inputtext, "5", true) == 0){
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo para ser removido\n\n");
					path = SaveCarNomePlay(playerid);
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i) {33CC33}R$%i\n",i, NomeDosCarros[SCCarid-400],SCCarid, floatround(ValorDosCarros[i][0]/2));
							strcat(StrMV, FtrMV);
						}
					}
	                ShowPlayerDialog(playerid, NIDConseCSell, DIALOG_STYLE_INPUT, "Vender Veiculo", StrMV, "OK", "Cancelar");
			        return 1;
			    }
			    else if(strcmp(inputtext, "6", true) == 0){
					new path[50],StrCAR[24], FtrMV[64],StrMV[1000];
					strcat(StrMV, "{00FF00}Digite o numero do veiculo para ser Vendio para outro player\n");
					strcat(StrMV, "{00FF00}Digite: [playerid][Slot][Valor]\n");
					path = SaveCarNomePlay(playerid);
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						new SCCarid = DOF2_GetInt(path,StrCAR);
						if(SCCarid >= 400){
							format(FtrMV, sizeof(FtrMV), "{FF6347}[%i]{FFFFFF} - %s(%i) {33CC33}R$%i\n",i, NomeDosCarros[SCCarid-400],SCCarid, floatround(ValorDosCarros[i][0]/2));
							strcat(StrMV, FtrMV);
						}
					}
	                ShowPlayerDialog(playerid, SellCarPlyPly, DIALOG_STYLE_INPUT, "Vender Veiculo para outro jogador", StrMV, "OK", "Cancelar");
			        return 1;
			    }
			    else if(strcmp(inputtext, "7", true) == 0){
					new xValor = pAceitar[playerid][0], xPlayer = pAceitar[playerid][1], xSlot = pAceitar[playerid][2],	PegarNome[32], ySlot = -1,string[128];
				    if(pAceitar[playerid][0] == 0) return SendClientMessage(playerid, 0xFFFFFFFF, "Voce nao tem nenhuma solicita��o de venda de veiculos!");
				    if(GetPlayerMoney(playerid) < xValor) return SendClientMessage(playerid, 0xFFFFFFFF, "Voc� n�o tem dinheiro suficiente!");
				    if(SVCarPLAYER[xSlot][xPlayer] == 0) return SendClientMessage(playerid, 0xFFFFFFFF, "O Veiculo do jogador nao esta Spawnado!");
					new path[50],StrCAR[24];
					path = SaveCarNomePlay(xPlayer);
					format(StrCAR, sizeof(StrCAR), "CarID_%i", xSlot);
					new SCCarid = DOF2_GetInt(path,StrCAR);
					if(SCCarid < 400) return SendClientMessage(playerid, 0xFFFFFFFF, "Este jogador nao possui mais este Veiculo!");
					for(new i = 0; i < QntSlotCar; i++){
						format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
						if(DOF2_GetInt(path,StrCAR) == 0){ ySlot = i; break; }
					}
					if(ySlot == -1) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao tem Slots suficiente!");
				    GivePlayerMoney(xPlayer,xValor);
				    GivePlayerMoney(playerid,-xValor);
	        		GetPlayerName(xPlayer, PegarNome, sizeof(PegarNome));
					format(string, sizeof(string), "Voc� comprou o veiculo (%s) do %s(%i) por R$%i", NomeDosCarros[SCCarid-400],PegarNome,xPlayer,xValor);
					SendClientMessage(playerid, 0xFFFFFFFF, string);
					GetPlayerName(playerid, PegarNome, sizeof(PegarNome));
					format(string, sizeof(string), "Jogador %s(%i) comprou o seu veiculo (%s) por R$%i", NomeDosCarros[SCCarid-400],PegarNome,playerid,xValor);
					SendClientMessage(xPlayer, 0xFFFFFFFF, string);
					SVCarPLAYER[ySlot][playerid] = SVCarPLAYER[xSlot][xPlayer];
	  				path = SaveCarNomePlay(xPlayer);
					format(StrCAR, sizeof(StrCAR), "CarID_%i", xSlot);
					DOF2_SetInt(path,StrCAR,0);
					SVCarPLAYER[xSlot][xPlayer] = 0;
				    pAceitar[playerid][0] = 0;//VALOR
				    pAceitar[playerid][1] = 0;//PLAYERID
				    pAceitar[playerid][2] = 0;//SLOT
				    DOF2_SaveFile();
			        return 1;
			    }
			    else if(strcmp(inputtext, "8", true) == 0){
				    if(!IsPlayerInAnyVehicle(playerid)) return SendClientMessage(playerid, 0xFF0000FF, "Voc� n�o est� em um carro!");
					if(pTrancarCAR[GetPlayerVehicleID(playerid)] > 0) return SendClientMessage(playerid, 0xFF0000FF, "Este veiculo j� esta trancado!");
					pTrancarCAR[GetPlayerVehicleID(playerid)] = playerid+1;
			    }
			    else if(strcmp(inputtext, "9", true) == 0){
					new veiculo = -1,Float:PosCar[3];
					for(new i = 0; i < 2000; i++){
					    GetVehiclePos(i,PosCar[0],PosCar[1],PosCar[2]);
					    if(IsPlayerInRangeOfPoint(playerid,5.0,PosCar[0],PosCar[1],PosCar[2])){ veiculo = i;break;}
					}
					if(veiculo == -1) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao esta proximo a nenhum veiculo!");
					if(pTrancarCAR[veiculo] == 0) return SendClientMessage(playerid, 0xFF0000FF, "Este veiculo nao esta trancado!");
					if(pTrancarCAR[veiculo]-1 != playerid) return SendClientMessage(playerid, 0xFF0000FF, "Voc� n�o possui as chaves deste veiculo!");
					pTrancarCAR[veiculo] = 0;
			    }
    			else SendClientMessage(playerid, 0xFF0000FF, "Opcao Invalida!");
        		return 1;
    }
	if(dialogid == NIDConseCarsC5){
		  	if(response){
			        new SlcCAR = strval(inputtext), StrCAR[128],Float:PosV[3];
			        if(SlcCAR >= 5) return SendClientMessage(playerid, 0xFF0000AA, "{6495ED}Voce digitou um numero invalido!");
			        if(SVCarPLAYER[SlcCAR][playerid] == 0) return SendClientMessage(playerid, 0xFF0000FF, "{6495ED}Voce nao pegou seu veiculo.");
			        if(AlguemNoCarro(SVCarPLAYER[SlcCAR][playerid]) == 1) return SendClientMessage(playerid, 0xFF0000FF,"Tem alguem dentro do seu veiculo!");
	                GetVehiclePos(SVCarPLAYER[SlcCAR][playerid],PosV[0],PosV[1],PosV[2]);
	                if(!IsPlayerInRangeOfPoint(playerid,20.0,PosV[0],PosV[1],PosV[2])) return SendClientMessage(playerid, 0xFF0000AA, "Voce nao esta perto o suficiente do seu veiculo!");
					DestroyVehicle(SVCarPLAYER[SlcCAR][playerid]);
	                format(StrCAR, sizeof(StrCAR), "Voce removeu seu veiuclo (%i)", SlcCAR);
	                SendClientMessage(playerid, 0xFF0000AA, StrCAR);
	                SVCarPLAYER[SlcCAR][playerid] = 0;
	        }
	        TogglePlayerControllable(playerid, true);
	        return 1;
	}
	if(dialogid == NIDConseCarsC3){
		  	if(response){
			        new SlcCAR = strval(inputtext);
			        if(SlcCAR >= 5) return SendClientMessage(playerid, 0xFF0000FF, "Voce digitou um numero invalido!");
			        if(SVCarPLAYER[SlcCAR][playerid] != 0) return SendClientMessage(playerid, 0xFF0000FF, "Voce ja pegou o veiculo deste slot!");
					new path[50],StrCAR[64], SCCarid, Float:PosSC[4];
					path = SaveCarNomePlay(playerid);
					format(StrCAR, sizeof(StrCAR), "CarID_%i", SlcCAR);
					SCCarid = DOF2_GetInt(path,StrCAR);
					format(StrCAR, sizeof(StrCAR), "PosX_%i", SlcCAR);
				   	PosSC[0] = DOF2_GetFloat(path,StrCAR);
				   	format(StrCAR, sizeof(StrCAR), "PosY_%i", SlcCAR);
				   	PosSC[1] = DOF2_GetFloat(path,StrCAR);
				   	format(StrCAR, sizeof(StrCAR), "PosZ_%i", SlcCAR);
				   	PosSC[2] = DOF2_GetFloat(path,StrCAR);
				   	format(StrCAR, sizeof(StrCAR), "PosA_%i", SlcCAR);
				   	PosSC[3] = DOF2_GetFloat(path,StrCAR);
					format(StrCAR, sizeof(StrCAR), "Cor_%i", SlcCAR);
					SvCarCOR[SlcCAR][playerid] = DOF2_GetInt(path,StrCAR);
				   	DestroyVehicle(SVCarPLAYER[SlcCAR][playerid]);
				   	SVCarPLAYER[SlcCAR][playerid] = AddStaticVehicleEx(SCCarid,PosSC[0],PosSC[1],PosSC[2],PosSC[3],SvCarCOR[SlcCAR][playerid],SvCarCOR[SlcCAR][playerid],-1);
				   	SetVehicleHealth(SVCarPLAYER[SlcCAR][playerid], 650.0);
				   	SendClientMessage(playerid, 0xFF0000FF, "Seu veiculo esta no local estacionado.");
	        }
	        TogglePlayerControllable(playerid, true);
	        return 1;
	}
	if(dialogid == NIDConseCarsC2){
	  	if(response){
		        new SlcCAR = strval(inputtext);
		        if(SlcCAR >= QntSlotCar) return SendClientMessage(playerid, 0xFF0000FF, "Voce digitou um numero invalido!");
		        if(SVCarPLAYER[SlcCAR][playerid] == 0) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao pegou seu veiculo.");
		        new Float:PosV[3],StrCAR[128];
		        GetVehiclePos(SVCarPLAYER[SlcCAR][playerid],PosV[0],PosV[1],PosV[2]);
		        if(floatround(PosV[0]) == 0 && floatround(PosV[1]) == 0){
		            SVCarPLAYER[SlcCAR][playerid] = 0;
		            format(StrCAR, sizeof(StrCAR), "Seu veiculo (%i) foi Sincronizado! Pegue novamente", SlcCAR);
		            SendClientMessage(playerid, 0xFFFF00FF, StrCAR);
		            return 1;
		        }
                SetPlayerCheckpoint(playerid, PosV[0],PosV[1],PosV[2], 6.0);
                format(StrCAR, sizeof(StrCAR), "Voce localizou o seu veiculo (%i)", SlcCAR);
                SendClientMessage(playerid, 0xFFFF00FF, StrCAR);
                SVC_Localizar[playerid] = 1;
        }
        TogglePlayerControllable(playerid, true);
        return 1;
	}
	if(dialogid == NIDConseCarsC1){
		  	if(response){
					new SlcCAR = strval(inputtext);
					if(SlcCAR >= 5) return SendClientMessage(playerid, 0xFF0000AA, "Voce digitou um numero invalido!");
					new path[50],StrCAR[64], SCCarid, Float:PosSC[4];
	    			SCCarid = GetPlayerVehicleID(playerid);
					if(SCCarid != SVCarPLAYER[SlcCAR][playerid]) return SendClientMessage(playerid, 0xFF0000FF, "Este carro nao e seu, ou nao foi comprado!");
					path = SaveCarNomePlay(playerid);
					if(!DOF2_FileExists(path)) DOF2_CreateFile(path);
					GetVehiclePos(SCCarid, PosSC[0],PosSC[1],PosSC[2]);
					GetVehicleZAngle(SCCarid, PosSC[3]);
					format(StrCAR, sizeof(StrCAR), "CarID_%i", SlcCAR);
					DOF2_SetInt(path,StrCAR,GetVehicleModel(GetPlayerVehicleID(playerid)));
					format(StrCAR, sizeof(StrCAR), "PosX_%i", SlcCAR);
					DOF2_SetFloat(path,StrCAR,PosSC[0]);
					format(StrCAR, sizeof(StrCAR), "PosY_%i", SlcCAR);
					DOF2_SetFloat(path,StrCAR,PosSC[1]);
					format(StrCAR, sizeof(StrCAR), "PosZ_%i", SlcCAR);
					DOF2_SetFloat(path,StrCAR,PosSC[2]);
					format(StrCAR, sizeof(StrCAR), "PosA_%i", SlcCAR);
					DOF2_SetFloat(path,StrCAR,PosSC[3]);
					format(StrCAR, sizeof(StrCAR), "Cor_%i", SlcCAR);
					DOF2_SetInt(path,StrCAR,SvCarCOR[SlcCAR][playerid]);
					DOF2_SaveFile();
			        SendClientMessage(playerid, 0xFF0000FF, "voce estacionou seu carro aqui!");
	        }
	        return 1;
	}
	if(dialogid == NIDConseCSell){
		if(response){
			new SlcCAR = strval(inputtext),path[50],StrCAR[64],StrMsg[128],pModelo;
			new pValor = floatround(ValorDosCarros[SlcCAR][0]/2);
			path = SaveCarNomePlay(playerid);
			format(StrCAR, sizeof(StrCAR), "CarID_%i", SlcCAR);
			pModelo = DOF2_GetInt(path,StrCAR);
			DOF2_SetInt(path,StrCAR,0);
			format(StrMsg, sizeof(StrMsg), "Voce vendeu o veiculo %s por {33CC33}R$%i", NomeDosCarros[pModelo-400],pValor);
			SendClientMessage(playerid,0xFFFFFFFF,StrMsg);
			GivePlayerMoney(playerid,pValor);
		   	DestroyVehicle(SVCarPLAYER[SlcCAR][playerid]);
		   	SVCarPLAYER[SlcCAR][playerid] = 0;
		    DOF2_SaveFile();
		}
		return 1;
	}
	if(dialogid == NIDConseCor){
		if(response){
	        new string[128],StrCAR[64],path[50],Slot = -1,DefCar = SvSelcCar[playerid], pCor = listitem;//
	     	if(GetPlayerMoney(playerid) < ValorDosCarros[DefCar][0]){
		        format(string, sizeof(string), "Voce nao tem dinheiro suficiente para comprar o %s(%i) por {33CC33}R$%i",ValorDosCarros[DefCar][2],ValorDosCarros[DefCar][1],ValorDosCarros[DefCar][0]);
		        return SendClientMessage(playerid, 0xFFFFFFFF, string);
	     	}
	     	path = SaveCarNomePlay(playerid);
			for(new i = 0; i < QntSlotCar; i++){
				format(StrCAR, sizeof(StrCAR), "CarID_%i", i);
				if(DOF2_GetInt(path,StrCAR) == 0){ Slot = i; break; }
			}
			if(Slot == -1) return SendClientMessage(playerid, 0xFF0000FF, "Voce nao tem Slots suficiente!");
			if(pCor < 0 || pCor > 255) return SendClientMessage(playerid, 0xFF0000FF, "Use cores de 0~255!");
			SvCarCOR[Slot][playerid] = pCor;
	        GivePlayerMoney(playerid,-ValorDosCarros[DefCar][0]);
	        DestroyVehicle(SVCarPLAYER[Slot][playerid]);
	        SVCarPLAYER[Slot][playerid] = AddStaticVehicleEx(ValorDosCarros[DefCar][1],2124.9561,-1132.2983,25.4612+5.0,350.3899,pCor,pCor,-1);
	        format(string, sizeof(string), "Voce comprou {00FCFC}%s(%i){FFFFFF} por {33CC33}R$%i!",ValorDosCarros[DefCar][3],ValorDosCarros[DefCar][1],ValorDosCarros[DefCar][0]);
	        SendClientMessage(playerid, 0xFFFFFFFF, string);
	        return 1;
		}
		return 1;
	}
	if(dialogid == SellCarPlyPly){
		if(response){
			new xPlayer,xValor,xSlot,playername[32],string[128];
			if(sscanf(inputtext,"iii",xPlayer,xSlot,xValor)) return SendClientMessage(playerid , 0xFF0000FF , "Uso Correto /vendercarro [playerid][Slot][Valor]");
			if(SVCarPLAYER[xSlot][playerid] == 0) return SendClientMessage(playerid, 0xFFFFFFFF, "Voc� n�o est� com o seu veiculo Spawnado!");
			if(!IsPlayerConnected(xPlayer)) return SendClientMessage(playerid, 0xFFFFFFFF, "Este jogador n�o esta conectado!");
		    new Float:PosP[3]; GetPlayerPos(xPlayer,PosP[0],PosP[1],PosP[2]);
		    if(!IsPlayerInRangeOfPoint(playerid,5.0,PosP[0],PosP[1],PosP[2])) return SendClientMessage(playerid,0xFFFFFFFF,"Este jogador nao esta proximo a voce!");
			new path[50],StrCAR[24];
			path = SaveCarNomePlay(xPlayer);
			format(StrCAR, sizeof(StrCAR), "CarID_%i", xSlot);
			new SCCarid = DOF2_GetInt(path,StrCAR);
			if(SCCarid < 400) return SendClientMessage(playerid, 0xFFFFFFFF, "Voce nao possui nenhum veiculo neste slot!");
			pAceitar[xPlayer][0] = xValor;//Valor do Veiculo
			pAceitar[xPlayer][1] = playerid;//ID do jogador que vendeu
			pAceitar[xPlayer][2] = xSlot;//SLOT
	        GetPlayerName(playerid, playername, sizeof(playername));
	        format(string, sizeof(string), "[VEICULO]{FFFFFF} %s(%i) Quer te vender o veiculo (%s) por R$%i (/menucar, op��o [7])", playername,playerid,NomeDosCarros[SCCarid-400],xValor);
	        SendClientMessage(xPlayer, 0xFF0000FF, string);
	        GetPlayerName(xPlayer, playername, sizeof(playername));
	        format(string, sizeof(string), "[VEICULO]{FFFFFF} Voce enviou uma solicita��o de venda do veiculo (%s) para o %s(%i) por R$%i", NomeDosCarros[SCCarid-400],playername,xPlayer,xValor);
	        SendClientMessage(playerid, 0xFF0000FF, string);
		}
		return 1;
	}
    if(dialogid == Dial_conseTX){
		SvSelcCar[playerid] = listitem-1;
		new StrChatADM[500];
        strcat(StrChatADM, "{FFFFFF}Preto\n");
        strcat(StrChatADM, "Branco\n");
        strcat(StrChatADM, "Azul Claro\n");
        strcat(StrChatADM, "Vermelho\n");
        strcat(StrChatADM, "Cinza\n");
        strcat(StrChatADM, "Roxo Claro\n");
        strcat(StrChatADM, "Amarelo\n");
        strcat(StrChatADM, "Azul C�u\n");
        strcat(StrChatADM, "Metalido\n");
        strcat(StrChatADM, "Cinza Escuro\n");
		ShowPlayerDialog(playerid, NIDConseCor, DIALOG_STYLE_LIST, "Seleciona a cor", StrChatADM, "Ok", "Cancelar");
    }
	return 1;
}

public VerificarPasta(pasta[])
{
	format(String, sizeof(String), "%s/verificacao",pasta);
	DOF2_CreateFile(String);
	print("Verificando pastas....");
	if(DOF2_FileExists(String))
	{
	    printf("Pasta '%s' Encontrada e carregada com sucesso.", pasta);
	}
	else if(!DOF2_FileExists(String))
	{
	    printf("Pasta '%s' Nao encontrada. Crie ela e adicione.", pasta);
	}
	DOF2_RemoveFile(String);
	return 1;
}

public OnPlayerClickMap(playerid, Float:fX, Float:fY, Float:fZ)
{
	if(PlayerInfo[playerid][Admin]>0)
	{
		if(PlayerInfo[playerid][Trabalhando] == true)
		{
			SetPlayerPos(playerid,fX,fY,fZ);
			return 1;
		}
	}
	return 0;
}
public OnPlayerClickPlayer(playerid, clickedplayerid, source)
{
	return 1;
}
public kick(playerid)
{
	Kick(playerid);
	return 1;
}
forward CarregarEmpresa1(playerid);
public CarregarEmpresa1(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -1106.7115,-1621.1210,76.3672, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa1[playerid] = true;
    return 1;
}
forward DescarregarEmpresa1(playerid);
public DescarregarEmpresa1(playerid)
{
	CarregouEmpresa1[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 1000);
	return 1;
}
forward CarregarEmpresa2(playerid);
public CarregarEmpresa2(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -1058.9387,-1195.3838,129.2188, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa2[playerid] = true;
    return 1;
}
forward DescarregarEmpresa2(playerid);
public DescarregarEmpresa2(playerid)
{
	CarregouEmpresa2[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 2000);
	return 1;
}
forward CarregarEmpresa3(playerid);
public CarregarEmpresa3(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, 1986.3162,2051.4182,10.8203, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa3[playerid] = true;
    return 1;
}
forward DescarregarEmpresa3(playerid);
public DescarregarEmpresa3(playerid)
{
	CarregouEmpresa3[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 3000);
	return 1;
}
forward CarregarEmpresa4(playerid);
public CarregarEmpresa4(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, 1898.4686,2089.5432,10.8203, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa4[playerid] = true;
    return 1;
}
forward DescarregarEmpresa4(playerid);
public DescarregarEmpresa4(playerid)
{
	CarregouEmpresa4[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 4000);
	return 1;
}
forward CarregarEmpresa5(playerid);
public CarregarEmpresa5(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, 590.8334,856.4233,-43.0295, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa5[playerid] = true;
    return 1;
}
forward DescarregarEmpresa5(playerid);
public DescarregarEmpresa5(playerid)
{
	CarregouEmpresa5[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 5000);
	return 1;
}
forward CarregarEmpresa6(playerid);
public CarregarEmpresa6(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -2458.6843,786.8185,35.1719, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa6[playerid] = true;
    return 1;
}
forward DescarregarEmpresa6(playerid);
public DescarregarEmpresa6(playerid)
{
	CarregouEmpresa6[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 6000);
	return 1;
}
forward CarregarEmpresa7(playerid);
public CarregarEmpresa7(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -2767.8296,-406.1090,7.1799, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa7[playerid] = true;
    return 1;
}
forward DescarregarEmpresa7(playerid);
public DescarregarEmpresa7(playerid)
{
	CarregouEmpresa7[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 7000);
	return 1;
}
forward CarregarEmpresa8(playerid);
public CarregarEmpresa8(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -1707.6022,12.9511,3.5547, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa8[playerid] = true;
    return 1;
}
forward DescarregarEmpresa8(playerid);
public DescarregarEmpresa8(playerid)
{
	CarregouEmpresa8[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 8000);
	return 1;
}
forward CarregarEmpresa9(playerid);
public CarregarEmpresa9(playerid)
{
    TogglePlayerControllable(playerid, 1);
	SetPlayerCheckpoint(playerid, -1051.1932,-675.4248,31.9267, 5.0);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Carregada Com Sucesso Descarregue no Checkpoint");
 	CaminhaoEmpresa9[playerid] = true;
    return 1;
}
forward DescarregarEmpresa9(playerid);
public DescarregarEmpresa9(playerid)
{
	CarregouEmpresa9[playerid] = 0;
	TogglePlayerControllable(playerid, 1);
	SendClientMessage(playerid, -1, "{00FF00}[CARGA] Carga Descarregada Com Sucesso");
	GivePlayerMoney(playerid, 9000);
	return 1;
}
public Respawn()
{
	SendClientMessageToAll(-1, "{FF0000}[RC] {FFFFFF}Atencao os Veiculos sem Motorista serao Respawnandos em 1 minuto!!");
	SetTimer("respawn", 60000, false);
	return 1;
}
public respawn()
{
	SendClientMessageToAll(-1, "{FF0000}[RC] {FFFFFF}Todos os veiculos Desocupados forao Respawnandos");
	new a;
    for(new c = 0; c < MAX_VEHICLES; c++)
    {   for(new i = 0;i<MAX_PLAYERS;i++){
			if(IsPlayerInVehicle(i,c)){
				a++;
			}
		}
		if(a == 0){
			if(c <= existe){
				SetVehicleToRespawn(c);
			}else{DestroyVehicle(c);}
		}
	   	a = 0;
	}
	return 1;
}
public Registrando(playerid)
{
	new string[256];
    format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) ao Servidor\nNome: {708090}%s\n{FFFFFF}Conta: {FF0000}Nao Registrada\n{FFFFFF}Digite sua senha de Registro", PlayerName(playerid));
    ShowPlayerDialog(playerid, DIALOG_REGISTRO, DIALOG_STYLE_PASSWORD, "Registro", string, "Registrar", "Cancelar");
    Limparchat(playerid);
	SetPlayerPos(playerid, 1958.3783, 1343.1572, 15.3746);
	SetPlayerCameraPos(playerid, -1656.6704,-2702.9834,78.1913);
	SetPlayerCameraLookAt(playerid, 77.7586, -1821.3975, 26.7903);
    return 1;
}
public Logando(playerid)
{
    new string[256];
    format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
    ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
    Limparchat(playerid);
	SetPlayerPos(playerid, 1958.3783, 1343.1572, 15.3746);
	SetPlayerCameraPos(playerid, -1656.6704,-2702.9834,78.1913);
    SetPlayerCameraLookAt(playerid, 77.7586, -1821.3975, 26.7903);
	return 1;
}
public Abastecendo(playerid)
{
    if(Refueling[playerid] == 1)
    {
	    new i = GetPlayerVehicleID(playerid);
	    Vehicle[i][v_combustivel] = 100;
	    Refueling[playerid] = 0;
	}
    return 1;
}
public tpreso(playerid)
{
    SetPlayerPos(playerid, 1538.242553, -1673.189453, 13.546875);
    SetPlayerInterior(playerid,0);
    format(arquivo, sizeof(arquivo), "Presos/%s.txt", PlayerName(playerid));
    DOF2_RemoveFile(arquivo);
    format(arquivo, sizeof(arquivo), "Ficha/%s.txt", PlayerName(playerid));
    DOF2_RemoveFile(arquivo);
    SetPlayerHealth(playerid,100);
	return 1;
}
public Timer_Veiculos(playerid)
{
	if(IsPlayerConnected(playerid))
	{
		if(IsPlayerInAnyVehicle(playerid))
		{
            static vehicleid, string[128] = '\0';
            string[0] = '\0';
            vehicleid = GetPlayerVehicleID(playerid);

           	GetVehicleHealth(vehicleid, Vehicle[vehicleid][v_lataria]);
            format(string, sizeof(string), "~n~~n~~n~~n~~n~~n~~n~~n~~n~~n~ ~y~KM/H ~w~%02d ~y~GAS: ~w~%02d", Vehicle_Velocity(vehicleid), Vehicle[vehicleid][v_combustivel]);
            GameTextForPlayer(playerid, string, 120 + GetPlayerPing(playerid), 3);

            if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER && Vehicle_Velocity(vehicleid) > 5)
            {
            	if(Vehicle[vehicleid][v_combustivel])
            	{
            		if(++Vehicle[vehicleid][v_time_count] >= 50)
            		{
            			if(++Vehicle[vehicleid][v_calc_comb] >= 10)
            			{
            				Vehicle[vehicleid][v_combustivel] -= 1;
            				Vehicle[vehicleid][v_calc_comb] = 0;
            			}
            			Vehicle[vehicleid][v_time_count] = 0;
            		}
                    GetVehicleParamsEx(vehicleid, mot, lu, alar, por, cap, porma, ob);
                    SetVehicleParamsEx(vehicleid, VEHICLE_PARAMS_ON, lu, alar, por, cap, porma, ob);
                }
                else
                {
                    GetVehicleParamsEx(vehicleid, mot, lu, alar, por, cap, porma, ob);
                    SetVehicleParamsEx(vehicleid, VEHICLE_PARAMS_OFF, lu, alar, por, cap, porma, ob);
                    GameTextForPlayer(playerid,"~r~Veiculo sem combustivel.", 1000, 3);
                }
            }
		}
	}
	return 1;
}
Vehicle_Velocity(vehicleid)
{
    new Float:xPos[3];
    GetVehicleVelocity(vehicleid, xPos[0], xPos[1], xPos[2]);
    return floatround(floatsqroot(xPos[0] * xPos[0] + xPos[1] * xPos[1] + xPos[2] * xPos[2]) * 170.00);
}
public MensagensCC()
{
	new string[256];
	new RandomMensagensC = random(sizeof(Mensagens));
	format(string, sizeof(string), "%s",Mensagens[RandomMensagensC]);
	SendClientMessageToAll(-1, string);
    return 1;
}
public Real()
{
    new t[3];
    gettime(t[0], t[1], t[2]);
    SetWorldTime(t[0]);
    return true;
}
public SetarLevel()
{
	foreach(new i : Player)
	{
	    new str[256];
		PlayerInfo[i][Level]++;
		format(str, sizeof(str), "{00FF00}[UP]{FFFFFF} Voce passou de nivel! Agora o seu nivel e %i", PlayerInfo[i][Level]);
		SendClientMessage(i, -1, str);
	}
	return 1;
}
CMD:n(playerid,params[])
{
 	new msg[128];
	if(sscanf(params,"s",msg))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /n para falar no chat noob");
	format(String,sizeof(String),"{20B2AA}[Chat-Noob][/n][%i]%s: %s",playerid,PlayerName(playerid),msg);
	if(PlayerInfo[playerid][Admin] > 0)
	{
		if(PlayerInfo[playerid][Trabalhando] == true)
		{
            format(String,sizeof(String),"{20B2AA}[Chat-Noob][/n][{FF1493}ADM{20B2AA}]%s: %s",PlayerName(playerid), playerid, msg);
		}
	}
	SendClientMessageToAll(-1,String);
	return 1;
}
CMD:dance(playerid, params[])                                                                                                                                                                                                                                                                                                                           //R.I.Ban.
{
    new danca;
    if(sscanf(params, "d", danca)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use /dance [1~4]");
    if(danca > 4)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /dance [1~4]");
    switch(danca)
    {
        case 1: ApplyAnimation(playerid, "DANCING", "bd_clap", 4.1, 1, 1, 0, 0, 0);
        case 2: ApplyAnimation(playerid, "DANCING", "bd_clap1", 4.1, 1, 1, 0, 0, 0);
        case 3: ApplyAnimation(playerid, "DANCING", "dance_loop", 4.1, 1, 1, 0, 0, 0);
        case 4: ApplyAnimation(playerid, "DANCING", "DAN_Down_A", 4.1, 1, 1, 0, 0, 0);
    }
    return 1;
}
CMD:anuncio(playerid)
{
	new texto[128], string[128];
	format(string, sizeof(string), "{00FF00}Anuncio: %s @%s", texto, PlayerName(playerid));
	SendClientMessageToAll(-1,string);
	return 1;
}
CMD:eu(playerid, params[])
{
    new texto[128], string[128];
	new aname[MAX_PLAYER_NAME];
	GetPlayerName(playerid, aname, MAX_PLAYER_NAME);
   	if(sscanf(params, "s", texto)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use /eu [acao]");
    new Float:X, Float:Y, Float:Z;
    GetPlayerPos(playerid, X, Y, Z);
    format(string, sizeof(string), "*** %s %s.", aname, texto);
    for(new i; i<300;i++)
    {
    	if(IsPlayerInRangeOfPoint(i,10.0,X,Y,Z))SendClientMessage(i, COR_PURPLE, string);
    }
	printf("%s", string);
	return 1;
}
CMD:gritar(playerid, params[])
{
    new texto[128], string[128];
	new aname[MAX_PLAYER_NAME];
	GetPlayerName(playerid, aname, MAX_PLAYER_NAME);
   	if(sscanf(params, "s", texto)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use /gritar [texto]");
    new Float:X, Float:Y, Float:Z;
    GetPlayerPos(playerid, X, Y, Z);
    format(string, sizeof(string), "*** %s Grita: %s.", aname, texto);
    for(new i; i<300;i++)
    {
    	if(IsPlayerInRangeOfPoint(i,10.0,X,Y,Z))SendClientMessage(i, -1, string);
    }
	printf("%s", string);
	return 1;
}
CMD:punheta(playerid)
{
	ApplyAnimation(playerid,"PAULNMAC", "wank_loop", 1.800001, 1, 0, 0, 1, 600);
	return 1;
}

CMD:deitar(playerid)
{
	ApplyAnimation(playerid, "BEACH", "bather", 4.0, 1, 0, 0, 0, 0);
	return 1;
}
CMD:apontar(playerid)
{
	ApplyAnimation(playerid,"TEC","TEC_reload",4.1,0,1,1,1,1);
	return 1;
}
CMD:render(playerid)
{
	ApplyAnimation(playerid, "PED", "handsup", 4.1, 0, 0, 1, 1, 0, 0);
	ApplyAnimation(playerid, "PED", "handsup", 4.1, 0, 0, 1, 1, 0, 0);
	return 1;
}
CMD:anim(playerid)
{
	ClearAnimations(playerid);
	return 1;
}

CMD:pagar(playerid,params[])
{
	new id,rd,Float:x,Float:y,Float:z;
	GetPlayerPos(playerid,x,y,z);
	if(sscanf(params,"ii",id,rd))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /pagar [ID] [QUANTIA]");
	if(rd < 1)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] VALOR INVALIDO");
	if(GetPlayerMoney(playerid)< rd)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao tem esse dinheiro");
	if(!IsPlayerConnected(id))return 1;
	if(IsPlayerInRangeOfPoint(playerid,5,x,y,z))
	{
		GivePlayerMoney(playerid,-rd);
		GivePlayerMoney(id,rd);
		format(String,sizeof(String),"%s te pagou %i",PlayerName(playerid),rd);
		SendClientMessage(id,COR_PURPLE,String);
		SendClientMessage(playerid,-1,"{00FF00}Jogador Pago com sucesso");
	}
	return 1;
}
CMD:ajuda(playerid)
{
    ShowPlayerDialog(playerid,DIALOG_AJUDA,DIALOG_STYLE_LIST,"Ajuda Servidor", "1 - Comandos Geral\n2 - Comandos Empresas\n3 - Comandos Casas\n4 - Comandos Organiza��o", "Colocar","Cancelar");
	return 1;
}

CMD:motor(playerid)
{
    static vehicleid;
    vehicleid = GetPlayerVehicleID(playerid);
	if(GetPlayerState(playerid) != PLAYER_STATE_DRIVER)
	{
		SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voc� precisa ser motorista de um ve�culo!");
		return 1;
	}
	if(GetVehicleModel(vehicleid) == 510)
 	{
		return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voc� n�o pode desligar/ligar uma bicicleta.");
   	}
   	new motor,farois,alarme,doors,bonnet,boot,obj;
   	GetVehicleParamsEx(vehicleid, mot, lu, alar, por, cap, porma, ob);
	if(!mot)
	{
		SetVehicleParamsEx(GetPlayerVehicleID(playerid),1,farois,alarme,0,bonnet,boot,obj);
		format(String, sizeof(String), "* %s Ligou o Motor de seu Veiculo", PlayerName(playerid));
  		ProxDetector(10.0, playerid, String, COR_PURPLE);
	}
	else if(mot)
	{
		GetVehicleParamsEx(GetPlayerVehicleID(playerid),motor,farois,alarme,doors,bonnet,boot,obj);
    	SetVehicleParamsEx(GetPlayerVehicleID(playerid),farois,0,alarme,0,bonnet,boot,obj);
		format(String, sizeof(String), "* %s Desligou o Motor de seu Veiculo", PlayerName(playerid));
  		ProxDetector(10.0, playerid, String, COR_PURPLE);
    }
    return 1;
}
CMD:serra(playerid)
{
	SetPlayerPos(playerid, 2738.6176757813, 1097.9831542969, 7.3030099868774);
	return 1;
}
CMD:abastecer(playerid, params[])
{
	if(!IsPlayerInAnyVehicle(playerid))
	{
		SendClientMessage(playerid,-1, "{FF0000}[ERRO] Voc� nao esta em um ve�culo!");
		return true;
	}
	new i = GetPlayerVehicleID(playerid);
	if(Vehicle[i][v_combustivel] >= 100) return SendClientMessage(playerid,-1,"{FF0000}[ERRO] O tanque deste Veiculo j� est� cheio.");
	{
		GameTextForPlayer(playerid,"~n~~w~Reabastecendo~n~ ~r~~h~Aguarde",3003,3);
		SetTimerEx("Abastecendo", 7000, false, "i", playerid);
		TogglePlayerControllable(playerid, 0);
		Refueling[playerid] = 1;
	}
	return 1;
}

CMD:equipar(playerid)
{
    if(PlayerInfo[playerid][Org] == 1)//Policia Militar
	{
	    if(IsPlayerInRangeOfPoint(playerid, 6.0, 1530.2498,-1662.1816,6.2188))
		{
		    ShowPlayerDialog(playerid,DIALOG_PM,DIALOG_STYLE_LIST,"Armario Policia Militar", "1 - Farda Viatura\n2 - Farda Rocam\n3 - Farda TFM\n4 - Retirar Farda", "Colocar","Cancelar");
		}
	}
	if(PlayerInfo[playerid][Org] == 2)//Policia Rodoviaria
	{
		if(IsPlayerInRangeOfPoint(playerid, 6.0, -13.5890,-2489.5342,36.6484))
		{
		    ShowPlayerDialog(playerid,DIALOG_PRF,DIALOG_STYLE_LIST,"Armario Policia Rodoviaria", "1 - Farda Viatura\n2 - Farda Rocam\n3 - Farda TFM\n4 - Retirar Farda", "Colocar","Cancelar");
		}
	}
	if(PlayerInfo[playerid][Org] == 3)//GBM
	{
		if(IsPlayerInRangeOfPoint(playerid, 6.0, 34.1446,-2644.4697,40.7285))
		{
		    GivePlayerWeapon(playerid, 43, 100);
		}
	}
	if(PlayerInfo[playerid][Org] == 4)//Gang 31AM
	{
		if(IsPlayerInRangeOfPoint(playerid, 6.0, -350.8861,-1048.5265,59.3376))
		{
		    GivePlayerWeapon(playerid, 43, 100);
		}
	}
	if(PlayerInfo[playerid][Org] == 5)//GFM
	{
		if(IsPlayerInRangeOfPoint(playerid, 6.0, -91.3615,-1567.3782,2.6172))
		{
		    GivePlayerWeapon(playerid, 43, 100);
		}
	}
	return 1;
}
CMD:comprar(playerid)
{
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 295.0589,-38.5141,1001.5156))
	{
	    ShowPlayerDialog(playerid, DIALOG_ARMAS, DIALOG_STYLE_LIST, "Lista Armas", "{FFFFFF}1 - 9mm		{00FF00}R$30000\n{FFFFFF}2 - Silenced 9mm		{00FF00}R$50000\n{FFFFFF}3 - Desert Eagle		{00FF00}R$70000\n{FFFFFF}4 - Katana		{00FF00}R$2000\n{FFFFFF}5 - Faca		{00FF00}R$50", "Comprar", "Cancelar");
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 295.6003,-80.8117,1001.5156))
	{
	    ShowPlayerDialog(playerid, DIALOG_ARMAS, DIALOG_STYLE_LIST, "Lista Armas", "{FFFFFF}1 - 9mm		{00FF00}R$30000\n{FFFFFF}2 - Silenced 9mm		{00FF00}R$50000\n{FFFFFF}3 - Desert Eagle		{00FF00}R$70000\n{FFFFFF}4 - Katana		{00FF00}R$2000\n{FFFFFF}5 - Faca		{00FF00}R$50", "Comprar", "Cancelar");
	}
	return 1;
}

CMD:carregar(playerid)
{
    if(!IsPlayerInAnyVehicle(playerid))
	{
		SendClientMessage(playerid,-1, "{FF0000}[ERRO] Voc� nao esta em um ve�culo!");
		return true;
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, -376.5482,-1443.6276,25.7266))
	{
		if(CarregouEmpresa1[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
 		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
   			SetTimerEx("CarregarEmpresa1", 5000, false, "d", playerid);
  			CarregouEmpresa1[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, -72.2352,-1114.6338,1.0781))
    {
		if(CarregouEmpresa2[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa2", 5000, false, "d", playerid);
			CarregouEmpresa2[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 539.3470,-1291.5088,17.2422))
    {
  		if(CarregouEmpresa3[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa3", 5000, false, "d", playerid);
			CarregouEmpresa3[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 1175.4042,-904.3761,43.3001))
    {
  		if(CarregouEmpresa4[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa4", 5000, false, "d", playerid);
			CarregouEmpresa4[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 1253.3020,-1259.9574,13.2027))
    {
  		if(CarregouEmpresa5[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa5", 5000, false, "d", playerid);
			CarregouEmpresa5[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 2458.6934,-2079.2932,13.5469))
    {
  		if(CarregouEmpresa6[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa6", 5000, false, "d", playerid);
			CarregouEmpresa6[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 2169.0972,-2274.5005,13.3999))
    {
  		if(CarregouEmpresa7[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa7", 5000, false, "d", playerid);
			CarregouEmpresa7[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 2761.6682,-2453.7708,13.5491))
    {
       	if(CarregouEmpresa8[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa8", 5000, false, "d", playerid);
			CarregouEmpresa8[playerid] = 1;
		}
	}
	if(IsPlayerInRangeOfPoint(playerid, 6.0, 2181.3079,-1985.2875,13.5507))
    {
   		if(CarregouEmpresa9[playerid] == 1) return SendClientMessage(playerid, -1, "{FF0000}|[ERRO] Voc� ja carregou o Caminh�o");
		{
			TogglePlayerControllable(playerid, 0);
			GameTextForPlayer(playerid, "Carregando..", 5000, 1), PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
			SetTimerEx("CarregarEmpresa9", 5000, false, "d", playerid);
			CarregouEmpresa9[playerid] = 1;
		}
	}
	return 1;
}
CMD:radio(playerid, params[])
{
    new str[256], text[50], nome[24];
    GetPlayerName(playerid, nome, sizeof(nome));
    if(sscanf(params, "s[100]", text)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use: /radio (mensagem)");
    format(str, sizeof(str), "{FFD700}[Radio Global] %s diz:{FFFFFF} %s", nome, text);
    SendClientMessageToAll(-1, str);
    return 1;
}
CMD:prender(playerid,params[]){

	new tempo,id;
	if(PlayerInfo[playerid][Org] == 1 || PlayerInfo[playerid][Org] == 2)
	{
		if(sscanf(params,"ii",id,tempo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /prender [ID] [TEMPO]");
		format(String,sizeof(String),"{FF0000} Voce foi preso por %i minutos pelo %s %s",tempo,NomeOrg(PlayerInfo[playerid][Admin]),PlayerName(playerid));
        SendClientMessage(id,-1,String);
		tempo *= 60000;
        SetPlayerPos(id, 196.9844, 162.0234, 1002.6875);
        SetPlayerInterior(id,3);
	    PlayerInfo[id][Arrastado] = 0;
        SetTimerEx("tpreso",tempo,false,"i",id);
        ResetPlayerWeapons(id);
		format(arquivo, sizeof(arquivo), "Presos/%s.txt", PlayerName(id));
		DOF2_CreateFile(arquivo);
		DOF2_SetInt(arquivo, "Tempo Preso", tempo);
		DOF2_WriteFile();
		SetPlayerHealth(playerid,999999999);
		return 1;
	}
	return 1;
}
CMD:arr(playerid,params[])
{
	new id;
	if(PlayerInfo[playerid][Org]==0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao faz parte de nenhuma corp");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1, "{FF0000}[ERRO] Use /arr [ID]");
	if(!IsPlayerInAnyVehicle(playerid)) return SendClientMessage(playerid, -1,"{FF0000}[ERRO] Voce nao esta em um veiculo!");
    if(GetPlayerState(playerid) != PLAYER_STATE_DRIVER)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e o motorista");
    //if(!(IsPerto(playerid,id)))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao esta perto o bastante");
    PlayerInfo[id][Algemado] = false;
    PlayerInfo[id][Arrastado] = GetPlayerVehicleID(playerid);
    PutPlayerInVehicle(id,GetPlayerVehicleID(playerid),3);
    format(String,sizeof(String),"O %s arrastou o %s para o carro",PlayerName(playerid),PlayerName(id));
	//MsgPerto(playerid,COR_PURPLE,String);
	return 1;
}
CMD:rem(playerid,params[])
{
	new id;
	if(PlayerInfo[playerid][Org]==0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao faz parte de nenhuma corp");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /rem [ID]");
    //if(!(IsPerto(playerid,id)))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao esta perto o bastante");
    PlayerInfo[id][Algemado] = false;
    RemovePlayerFromVehicle(id);
    format(String,sizeof(String),"O %s retirou o %s do carro",PlayerName(playerid),PlayerName(id));
	//MsgPerto(playerid,COR_PURPLE,String);
	return 1;
}
CMD:lc(playerid)
{
    Limparchat(playerid);
    return 1;
}
CMD:veh(playerid, params[])
{
    {
        new Float:X, Float:Y, Float:Z, Float:A, Veiculo, Modelo, c1, c2;

        if(sscanf(params, "ddd", Modelo, c1, c2))
            return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use: /veh [Modelo] [cor1] [cor2]");

        if( Modelo < 400 || Modelo > 611 )
            return  SendClientMessage(playerid, -1, "{FF0000}[ERRO] ID Invalido use [400 a 611]");

        GetPlayerPos(playerid, X, Y, Z);
        GetPlayerFacingAngle(playerid, A);

        Veiculo =  CreateVehicle(Modelo, X, Y, Z, A, c1, c2, 100000);
        PutPlayerInVehicle(playerid, Veiculo, 0);

    }
	return 1;
}

CMD:respawn(playerid, params[])
{
    if(PlayerInfo[playerid][Admin] < 2) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Voce nao esta autorizado");
	SendClientMessageToAll(-1, "{FF0000}[RC] {FFFFFF}Atencao os Veiculos sem Motorista serao Respawnandos em 1 minuto!!");
	SetTimer("respawn", 60000, false);
	return 1;
}
CMD:clima(playerid,params[])
{
	new id;
	if(!(ADM(playerid,2)))return 1;
    if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /clima [ID]");
	SetWeather(id);
	return 1;
}
CMD:limparchat(playerid)
{
	if(!(ADM(playerid,2)))return 1;
	for(new a = 0; a < 100; a++)
    {
      SendClientMessageToAll(0xFFFFFFFF, " ");
    }
	return 1;
}
CMD:dargrana(playerid,params[])
{
	new id,grana;
	if(!(ADM(playerid,2))) return 1;
	if(sscanf(params,"ii",id,grana))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /dargrana [ID] [QUANTIA]");
	GivePlayerMoney(id,grana);
	format(String,sizeof(String),"{00FF00} O %s %s te deu %i de dinheiro.",NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid),grana);
	SendClientMessage(id,-1,String);
	SalvarDados(playerid);
	return 1;
}
CMD:tv(playerid,params[])
{
	new id;
    if(!(ADM(playerid,2))) return 1;
    if(sscanf(params,"i",id)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use /tv [ID]");
    if(id == playerid) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] voce nao pode assistir vc mesmo");
    if(!IsPlayerConnected(id)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Este Jogador nao esta Online");
	TogglePlayerSpectating(playerid, 1);
	PlayerSpectatePlayer(playerid, id);
	PlayerSpectateVehicle(playerid, GetPlayerVehicleID(id));
	return 1;
}
CMD:tvoff(playerid,params[])
{
    if(!(ADM(playerid,2))) return 1;
	TogglePlayerSpectating(playerid, 0);
	PlayerSpectatePlayer(playerid, playerid);
	PlayerSpectateVehicle(playerid, GetPlayerVehicleID(playerid));
	return 1;
}
CMD:aviso(playerid, params[])
{
	new msg[128];
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"s",msg))return SendClientMessage(playerid, -1,"{FF0000}Use /aviso [anuncio].");
	SendClientMessageToAll(-1, "{FF1493}============== AVISO ADMINSTRAC�O ==============");
	format(String,sizeof(String),"{FF1493}%s {FFFFFF}@%s", msg, PlayerName(playerid));
	SendClientMessageToAll(-1,String);
	return 1;
}
CMD:bantemp(playerid,params[])
{
	new id,motivo[256],tempo;
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"is[32]",id,motivo,tempo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /bantemp [ID] [MOTIVO][TEMPO]");
	format(arquivo,sizeof(arquivo),"Banidos/%s.txt",PlayerName(id));
	DOF2_CreateFile(arquivo);
	DOF2_SetString(arquivo,"ADM",PlayerName(playerid));
	DOF2_SetString(arquivo,"Motivo",motivo);
	format(String,sizeof(String),"{FF0000}[Ban] %s foi banido por %s",PlayerName(id),motivo);
	SendClientMessageToAll(-1,String);
	Kick(id);
	return 1;
}
CMD:skin(playerid, params[])
{
	new id;
	if(sscanf(params, "d", id)) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use: /skin [id]");
	if(id > 300) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use IDs entre 1 a 300");
	if(id <= 0) return SendClientMessage(playerid, -1, "{FF0000}[ERRO] Use IDs entre 1 a 300");
	SetPlayerSkin(playerid, id);
 	return 1;
}

CMD:dararma(playerid,params[])
{
	new id,armaid,municao;
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"iii[32]",id,armaid,municao))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /dararma [ID] [ID DA ARMA] [MUNIÇAO]");
	GivePlayerWeapon(id,armaid,municao);
	if(id == playerid)return 1;
	format(String,sizeof(String),"{FF1493}[AdminCmd] O %s %s te deu %i muniçoes",NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid),municao);
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{FF1493}[AdminCmd] Voce deu %i de municoes para %s",municao,PlayerName(id));
	SendClientMessage(playerid,-1,String);
	return 1;
}
CMD:tirararma(playerid,params[])
{
    new id;
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"i[32]",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /tirararma [ID]");
	ResetPlayerWeapons(id);
	if(id == playerid)return 1;
	format(String,sizeof(String),"{FF1493}[AdminCmd] O %s %s retirou suas armas",PlayerName(PlayerInfo[playerid][Admin]),PlayerName(playerid));
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{FF1493}[AdminCmd] Voce tirou as armas de %s",PlayerName(id));
	SendClientMessage(playerid,-1,String);
	return 1;
}
CMD:daradmin(playerid,params[])
{
	new Id,cargo;
	if(!(ADM(playerid,6))) return 1;
	if(sscanf(params,"ii[32]",Id,cargo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /daradmin [ID] [LEVEL]");
	if(cargo > 6)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Cargo Invalido Use 1 a 6.");
	if(playerid == Id)return 1;
	PlayerInfo[Id][Admin] = cargo;
	format(String,sizeof(String),"{FF1493}[AdminCmd] Voce setou %s para o Cargo de %s",PlayerName(Id),NomeAdm(cargo));
	SendClientMessage(playerid,-1,String);
	format(String,sizeof(String),"{FF1493}[Admin] O %s %s setou voce para o cargo de %s",NomeAdm(PlayerInfo[playerid][Admin]), PlayerName(playerid), NomeAdm(cargo));
	SendClientMessage(Id,-1,String);
	SalvarDados(Id);
	return 1;
}
CMD:admins(playerid, params[])
{
	new IsAdmin;
	SendClientMessage(playerid, -1, "{FF1493}========== Admin Online ==========");
	for(new i = 0; i < MAX_PLAYERS; i++)
	{
	    if(IsPlayerConnected(i))
		{
		    if(PlayerInfo[i][Admin] > 0)
		    {
		        if(PlayerInfo[i][Trabalhando] == true)
				{
	        		format(String, sizeof(String), "{FF1493}Nome: {FFFFFF}%s {FF1493}Cargo: {FFFFFF}%s", PlayerName(i), NomeAdm(PlayerInfo[i][Admin]));
		        	SendClientMessage(playerid, -1, String);
		        	IsAdmin ++;
				}
			}
		}
	}
	if(IsAdmin == 0)
	{
	    SendClientMessage(playerid, -1, "{FF0000}[ERRO] Nenhum Administrador Online");
	}
	IsAdmin = 0;
	return 1;
}
CMD:ir(playerid,params[])
{
	new Float:x,Float:y,Float:z,id;
	if(!(ADM(playerid,1))) return 1;
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /ir [ID]");
	if(IsPlayerConnected(id))
	{
		GetPlayerPos(id,x,y,z);
		SetPlayerInterior(playerid,GetPlayerInterior(id));
		SetPlayerPos(playerid,x,y,z);
		format(String,sizeof(String),"{1E90FF}[TP] O %s %s veio ate voce",NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid));
		SendClientMessage(id,-1,String);
		format(String,sizeof(String),"{1E90FF}[TP] Voce foi ate %s",PlayerName(id));
		SendClientMessage(playerid,-1,String);
	}
	else return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player nao esta online");
	return 1;
}
CMD:trazer(playerid,params[])
{
    new Float:x,Float:y,Float:z,id;
	if(!(ADM(playerid,1))) return 1;
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /trazer [ID]");
	if(IsPlayerConnected(id))
	{
		GetPlayerPos(playerid,x,y,z);
		SetPlayerInterior(id,GetPlayerInterior(playerid));
		SetPlayerPos(id,x,y,z);
		format(String,sizeof(String),"{1E90FF}[TP] O %s veio ate voce",PlayerName(id));
		SendClientMessage(playerid,-1,String);
		format(String,sizeof(String),"{1E90FF}[TP] Voce foi ate %s %s",NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid));
		SendClientMessage(id,-1,String);
	}
	else return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player nao esta online");
	return 1;
}
CMD:kick(playerid,params[])
{
	new id,motivo[128];
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"is[32]",id,motivo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /kick [ID] [MOTIVO]");
	format(String,sizeof(String),"{FF0000}[Kick] Voce foi kickado pelo admin %s motivo: %s",PlayerName(playerid),motivo);
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{FF0000}[Kick] %s foi kickado pelo admin %s motivo: %s",PlayerName(id),PlayerName(playerid), motivo);
	SendClientMessageToAll(-1,String);
	Kick(id);
	return 1;
}
CMD:ban(playerid,params[])
{
	new id,motivo[256];
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"is[32]",id,motivo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /ban [ID] [MOTIVO]");
	format(arquivo,sizeof(arquivo),"Banidos/%s.txt",PlayerName(id));
	DOF2_CreateFile(arquivo);
	DOF2_SetString(arquivo,"ADM",PlayerName(playerid));
	DOF2_SetString(arquivo,"Motivo",motivo);
	format(String,sizeof(String),"{FF0000}[Ban] %s foi banido pelo motivo: %s",PlayerName(id),motivo);
	SendClientMessageToAll(-1,String);
	Kick(id);
	return 1;
}
CMD:banip(playerid,params[])
{
	new id,motivo[256],Ip[25];
	if(!(ADM(playerid,2)))return 1;
	if(sscanf(params,"is[32]",id,motivo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /banip [ID] [MOTIVO]");
	GetPlayerIp(id,Ip,sizeof(Ip));
	format(arquivo,sizeof(arquivo),"BanidosIp/%s.txt",Ip);
	DOF2_CreateFile(arquivo);
	DOF2_SetString(arquivo,"Nome",PlayerName(id));
	DOF2_SetString(arquivo,"ADM",PlayerName(playerid));
	DOF2_SetString(arquivo,"Motivo",motivo);
	format(String,sizeof(String),"{FF0000}[Ban] %s foi banido por IP pelo motivo: %s",PlayerName(id),motivo);
	SendClientMessageToAll(-1,String);
	Kick(id);
	return 1;
}
CMD:a(playerid,params[])
{
	new text[128];
	if(!(ADM(playerid,1)))return 1;
	if(sscanf(params,"s[32]",text))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /a [Mensagem]");
	format(String,sizeof(String),"{FF1493}[Chat Admin] %s: {FFFFFF}%s", PlayerName(playerid),text);
	MsgAdm(String);
	return 1;
}
CMD:trabalhar(playerid)
{
	if(!(ADM(playerid,1))) return 1;
    if(PlayerInfo[playerid][Trabalhando] == false)
	{
        format(String, sizeof(String), "{FF1493}O %s %s entrou em modo trabalho",NomeAdm(PlayerInfo[playerid][Admin]), PlayerName(playerid));
    	SendClientMessageToAll(-1,String);
		PlayerInfo[playerid][Trabalhando] = true;
		SetPlayerSkin(playerid,217);
		SetPlayerColor(playerid, ROSA);
	}
	else
	{
 		SetPlayerHealth(playerid,100);
		PlayerInfo[playerid][Trabalhando] = false;
  		format(String, sizeof(String), "{FF1493}O %s %s saiu do modo trabalho",NomeAdm(PlayerInfo[playerid][Admin]), PlayerName(playerid));
   		SendClientMessageToAll(-1,String);
		SetPlayerSkin(playerid,PlayerInfo[playerid][Skin]);
		SetPlayerColor(playerid, BRANCO);
	}
	return 1;
}
CMD:cadeia(playerid,params[])
{
	new tempo,id;
    if(!(ADM(playerid,2)))return 1;
	if(PlayerInfo[playerid][Trabalhando] == true)
	{
		if(sscanf(params,"ii",id,tempo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /prender [ID] [TEMPO]");
		format(String,sizeof(String),"{FF0000}Voce foi preso por %i minutos pelo %s %s",tempo,NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid));
        SendClientMessage(id,-1,String);
		tempo *= 60000;
        SetPlayerPos(id, 196.9844, 162.0234, 1002.6875);
        SetPlayerInterior(id,3);
        SetTimerEx("tpreso",tempo,false,"i",id);
        ResetPlayerWeapons(id);
		format(arquivo, sizeof(arquivo), "Presos/%s.txt", PlayerName(id));
		DOF2_CreateFile(arquivo);
		DOF2_SetInt(arquivo, "Tempo Preso", tempo);
		DOF2_WriteFile();
		SetPlayerHealth(playerid,999999999);
		return 1;
	}
	return 1;
}
CMD:darlider(playerid,params[])
{
	new id,org;
	if(!(ADM(playerid,3)))return 1;
	if(sscanf(params,"ii",id,org))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /darlider [ID] [IDORG]");
	if(!(IsPlayerConnected(id)))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player está offline");
	PlayerInfo[id][Org] = org;PlayerInfo[id][Cargo] = 5;
	SalvarDados(playerid);
	format(String,sizeof(String),"{FF1493}O %s %s lhe deu lider da %s",NomeAdm(PlayerInfo[playerid][Admin]),PlayerName(playerid),NomeOrg(id));
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{FF1493}O player %s Agora � lider da %s",PlayerName(id),NomeOrg(id));
	SendClientMessageToAll(-1,String);
	SpawnPlayer(id);
	SalvarDados(id);
	return 1;
}
CMD:convidar(playerid,params[])
{
	new id;
	if(PlayerInfo[playerid][Org] == 0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao faz parte de nenhuma org/corp");
	if(PlayerInfo[playerid][Cargo] < 4)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e lider ou sub lider para convidar");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /convidar [ID]");
	if(PlayerInfo[id][Org] != 0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player ja faz parte de uma org/corp");
	PlayerInfo[id][convite] = PlayerInfo[playerid][Org];
	format(String,sizeof(String),"{1E90FF}Voce esta convidando o %s para a %s",PlayerName(id),NomeOrg(playerid));
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{1E90FF}O %s esta lhe convidando para a %s",PlayerName(playerid),NomeOrg(playerid));
	ShowPlayerDialog(id,DIALOG_CONVITE,DIALOG_STYLE_MSGBOX,"Convite",String,"Aceitar","Recusar");
	return 1;
}
CMD:demitir(playerid,params[])
{
	new id;
	if(PlayerInfo[playerid][Org] == 0)return 1;
	if(PlayerInfo[playerid][Cargo] < 4)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e lider ou sub lider para demitir");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /demitir [ID]");
	if(PlayerInfo[id][Org] != PlayerInfo[playerid][Org])return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player nao faz parte da sua org/corp");
	PlayerInfo[id][Org] = 0;PlayerInfo[id][Cargo] = 0;
	format(String,sizeof(String),"{FF0000}Voce esta demitindo o %s da %s",PlayerName(id),NomeOrg(playerid));
	SendClientMessage(id,-1,String);
	format(String,sizeof(String),"{FF0000}O %s esta lhe demitindo da %s",PlayerName(playerid),NomeOrg(playerid));
	SendClientMessage(id,-1,String);
	return 1;
}
CMD:promover(playerid,params[])
{
    new id,cargo;
	if(PlayerInfo[playerid][Org] == 0)return 1;
	if(PlayerInfo[playerid][Cargo] < 4)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e lider para promover");
	if(sscanf(params,"ii",id,cargo))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /promover [ID] [CARGO]");
	if(PlayerInfo[id][Org] != PlayerInfo[playerid][Org])return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Esse player nao faz parte da sua org/corp");
	PlayerInfo[id][Cargo] = cargo;
	format(String,sizeof(String),"{1E90FF} Voce promoveu o %s para %s",PlayerName(id),NomeCargo(id));
	SendClientMessage(playerid,-1,String);
	format(String,sizeof(String),"{1E90FF} O %s esta lhe promovendo para %s",PlayerName(playerid),NomeCargo(id));
	SendClientMessage(id,-1,String);
	return 1;
}

CMD:pedircontas(playerid)
{
	if(PlayerInfo[playerid][Org] == 0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao faz parte de nenhuma org/corp");
	if(PlayerInfo[playerid][Cargo] == 5)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce e o lider para pedir contas entre em contato com um adm");
	format(String,sizeof(String),"Voce saiu da org %s com sucesso",NomeOrg(playerid));
	SendClientMessage(playerid,-1,String);
	PlayerInfo[playerid][Org] = 0;PlayerInfo[playerid][Cargo] = 0;
	SpawnPlayer(playerid);
	return 1;
}
CMD:ab(playerid)
{
	if(PlayerInfo[playerid][Org] == 0)return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao faz parte de nenhuma org/corp");
	if((PlayerInfo[playerid][Org] > 1)&&(PlayerInfo[playerid][Org] < 2))
	{
		format(String,sizeof(String),"%s: PARE AGORA OU IREMOS ATIRAR",NomeOrg(playerid));
		ProxDetector(10.0, playerid, String, COR_PURPLE);
	}
	return 1;
}
CMD:algemar(playerid,params[])
{
	new Float:x,Float:y,Float:z,id;
	if((PlayerInfo[playerid][Org] < 3)&&(PlayerInfo[playerid][Org] > 5))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e policial para algemar");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /algemar [ID]");
	GetPlayerPos(playerid,x,y,z);
	if(!IsPlayerInRangeOfPoint(id,2,x,y,z))return SendClientMessage(playerid, -1,"{FF0000}[ERRO] Chegue mais perto para algemar");
	PlayerInfo[id][Algemado] = true;
	format(String,sizeof(String),"%s foi algemado pelo Policial %s",PlayerName(id),PlayerName(playerid));
	for(new i = 0;i<MAX_PLAYERS;i++)
	{
		if(IsPlayerInRangeOfPoint(i,5,x,y,z))
		{
			SendClientMessage(i,COR_PURPLE,String);
		}
	}
	return 1;
}
CMD:desalgemar(playerid,params[])
{
	new Float:x,Float:y,Float:z,id;
	if((PlayerInfo[playerid][Org] < 3)&&(PlayerInfo[playerid][Org] > 5))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Voce nao e policial para desalgemar");
	if(sscanf(params,"i",id))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /desalgemar [ID]");
	GetPlayerPos(playerid,x,y,z);
	if(!IsPlayerInRangeOfPoint(id,2,x,y,z))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Chegue mais perto para algemar");
	PlayerInfo[id][Algemado] = false;
	format(String,sizeof(String),"%s foi desalgemado pelo %s",PlayerName(id),PlayerName(playerid));
	for(new i = 0;i<MAX_PLAYERS;i++)
	{
		if(IsPlayerInRangeOfPoint(i,5,x,y,z))
		{
			SendClientMessage(i,COR_PURPLE,String);
		}
	}
	return 1;
}
CMD:d(playerid,params[])
{
	new msg[128];
	if(PlayerInfo[playerid][Org] < 1)return 1;
	if(PlayerInfo[playerid][Org] > 2)return 1;
	if(sscanf(params,"s",msg))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /d [MENSAGEM] para falar no departamento");
	format(String,sizeof(String),"{6495ED}Copom: %s: %s: {FFFFFF}%s",NomeOrg(playerid),PlayerName(playerid),msg);
	for(new i=0;i<MAX_PLAYERS;i++)
	{
		if((PlayerInfo[i][Org] >= 1)&&(PlayerInfo[i][Org] <= 2))
		{
			SendClientMessage(i,-1,String);
		}
	}
	return 1;
}
CMD:r(playerid,params[])
{
	new msg[128];
	if(PlayerInfo[playerid][Org] < 1)return 1;
	if(PlayerInfo[playerid][Org] > 2)return 1;
	if(sscanf(params,"s",msg))return SendClientMessage(playerid,-1,"{FF0000}[ERRO] Use /r [MENSAGEM] para falar com sua corp");
	format(String,sizeof(String),"{FFD700}Radio: %s:{FFFFFF} %s",PlayerName(playerid),msg);
	MsgOrg(playerid,String);
	return 1;
}
stock NomeCargo(playerid)
{
	new CARGO[40];
	if(PlayerInfo[playerid][Org] == 1)
	{
	    if(PlayerInfo[playerid][Cargo] == 1)
		{
			CARGO = "Recruta";
		}
		if(PlayerInfo[playerid][Cargo] == 2)
		{
			CARGO = "Soldado";
		}
		if(PlayerInfo[playerid][Cargo] == 3)
		{
			CARGO = "Coronel";
		}
		if(PlayerInfo[playerid][Cargo] == 4)
		{
			CARGO = "Sub-comandante";
		}
		if(PlayerInfo[playerid][Cargo] == 5)
		{
		    if(PlayerInfo[playerid][Org] == 1)
			{
                CARGO = "Marechal";
			}
			else
			{
				CARGO = "Comandante";
			}
		}
	}
	if(PlayerInfo[playerid][Org] == 2)
	{
	    if(PlayerInfo[playerid][Cargo] == 1)
		{
			CARGO = "Recruta";
		}
		if(PlayerInfo[playerid][Cargo] == 2)
		{
			CARGO = "Soldado";
		}
		if(PlayerInfo[playerid][Cargo] == 3)
		{
			CARGO = "Coronel";
		}
		if(PlayerInfo[playerid][Cargo] == 4)
		{
			CARGO = "Sub-comandante";
		}
		if(PlayerInfo[playerid][Cargo] == 5)
		{
		    if(PlayerInfo[playerid][Org] == 1)
			{
                CARGO = "Marechal";
			}
			else
			{
				CARGO = "Comandante";
			}
		}
	}
	if(PlayerInfo[playerid][Org] == 3)
	{
        if(PlayerInfo[playerid][Cargo] == 1)
		{
			CARGO = "Flogueiro";
		}
		if(PlayerInfo[playerid][Cargo] == 2)
		{
			CARGO = "Caminhoneiro";
		}
		if(PlayerInfo[playerid][Cargo] == 3)
		{
			CARGO = "Membro";
		}
		if(PlayerInfo[playerid][Cargo] == 4)
		{
			CARGO = "Sub-Chefe";
		}
		if(PlayerInfo[playerid][Cargo] == 5)
		{
			CARGO = "Chefe";
		}

	}
	if(PlayerInfo[playerid][Org] == 4)
	{
        if(PlayerInfo[playerid][Cargo] == 1)
		{
			CARGO = "Flogueiro";
		}
		if(PlayerInfo[playerid][Cargo] == 2)
		{
			CARGO = "Caminhoneiro";
		}
		if(PlayerInfo[playerid][Cargo] == 3)
		{
			CARGO = "Membro";
		}
		if(PlayerInfo[playerid][Cargo] == 4)
		{
			CARGO = "Sub-Chefe";
		}
		if(PlayerInfo[playerid][Cargo] == 5)
		{
			CARGO = "Chefe";
		}
	}
	if(PlayerInfo[playerid][Org] == 5)
	{
        if(PlayerInfo[playerid][Cargo] == 1)
		{
			CARGO = "Flogueiro";
		}
		if(PlayerInfo[playerid][Cargo] == 2)
		{
			CARGO = "Caminhoneiro";
		}
		if(PlayerInfo[playerid][Cargo] == 3)
		{
			CARGO = "Membro";
		}
		if(PlayerInfo[playerid][Cargo] == 4)
		{
			CARGO = "Sub-Chefe";
		}
		if(PlayerInfo[playerid][Cargo] == 5)
		{
			CARGO = "Chefe";
		}
	}
	return CARGO;
}
stock MsgOrg(playerid,msg[]){
	for(new i = 0;i<MAX_PLAYERS;i++)
	{
		if(PlayerInfo[playerid][Org] == PlayerInfo[i][Org]){
		    SendClientMessage(i,-1,msg);
		}
	}
	return 1;
}
stock NomeOrg(playerid)
{
	new orG[35],org;
	org = PlayerInfo[playerid][Org];
	if(org == 0)
	{
		orG = "Civil";
	}
	if(org == 1)
	{
		orG = "Policia Militar";
	}
	if(org == 2)
	{
		orG = "Policia Rodoviaria";
	}
	if(org == 3)
	{
		orG = "GBN";
	}
	if(org == 4)
	{
		orG = "Gang 31AM";
	}
	if(org == 5)
	{
		orG = "GFM";
	}
	return orG;
}
stock ProxDetector(Float:radi, playerid, string[],color)
{
    new Float:x,Float:y,Float:z;
    GetPlayerPos(playerid,x,y,z);
    foreach(Player,i)
    {
        if(IsPlayerInRangeOfPoint(i,radi,x,y,z))
        {
            SendClientMessage(i,color,string);
        }
    }
}
stock MsgAdm(mensagem[])
{
	for(new i = 0; i < MAX_PLAYERS; ++i)
	{
	    if(PlayerInfo[i][Admin] > 0)
	    {
			SendClientMessage(i, -1, mensagem);
		}
	}
	return 1;
}
stock ADM(playerid, lvl)
{
	if(PlayerInfo[playerid][Admin] == 0)
	{
		format(String, sizeof(String), "{FF0000}[ERRO] Voce nao esta autorizado a executar este comando");
		SendClientMessage(playerid, -1, String);
		return 0;
	}
	else if(PlayerInfo[playerid][Admin] < lvl)
	{
        format(String, sizeof(String), "{FF0000}[ERRO] Voce nao esta autorizado a executar este comando");
		SendClientMessage(playerid, -1, String);
		return 0;
	}
	return 1;
}
stock NomeAdm(cargo)
{
	new name[20];
	if(cargo == 1) name = "Ajudante";
	if(cargo == 2) name = "helper";
	if(cargo == 3) name = "Adminstrador";
	if(cargo == 4) name= "Gerente";
	if(cargo == 5) name= "SubDono";
	if(cargo == 6) name= "Dono";
	return name;
}
stock SalvarDados(playerid)
{
    format(arquivo, sizeof(arquivo), "Contas/%s.txt",PlayerName(playerid));
    DOF2_SetInt(arquivo, "Dinheiro", GetPlayerMoney(playerid));
    DOF2_SetInt(arquivo, "Skin", PlayerInfo[playerid][Skin]);
    DOF2_SetInt(arquivo, "Sexo", PlayerInfo[playerid][Sexo]);
    DOF2_SetInt(arquivo, "Admin", PlayerInfo[playerid][Admin]);
    DOF2_SetInt(arquivo, "Level", PlayerInfo[playerid][Level]);
    DOF2_SetInt(arquivo, "Org", PlayerInfo[playerid][Org]);
    DOF2_SetInt(arquivo, "Cargo", PlayerInfo[playerid][Cargo]);
    DOF2_SaveFile();
    return 1;
}


stock Limparchat(playerid)
{
	for(new a = 0; a < 100; a++)
    {
    	SendClientMessage(playerid, -1, "");
    }
	return 1;
}
stock PlayerName(playerid)
{
	new sendername[MAX_PLAYER_NAME];
	GetPlayerName(playerid, sendername, sizeof(sendername));
	return ( sendername );
}
stock SendClientMessageInRange(Float:_r, playerid, _s[],c1,c2,c3,c4,c5)
{
	new Float:_x, Float:_y, Float:_z;
	GetPlayerPos(playerid, _x, _y, _z);
    for(new i=0; i<MAX_PLAYERS; i++)
	{
		if(IsPlayerConnected(i))
		{
		    if(GetPlayerVirtualWorld(i) != GetPlayerVirtualWorld(playerid))continue;
			if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/16)
				SendClientMessage(i, c1, _s);
			else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/8)
				SendClientMessage(i, c2, _s);
			else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/4)
				SendClientMessage(i, c3, _s);
			else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/2)
				SendClientMessage(i, c4, _s);
			else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r)
				SendClientMessage(i, c5, _s);
		}
	}
	return true;
}

SCBR::IrAviao(playerid)
{
	ObjetoAviao[playerid] = CreateObject(14553, 2215.55127, -2491.83008, 73.72130,   13.50000, 0.00000, -87.84000, 500.0);
	SetPlayerVirtualWorld(playerid, playerid);
	SetPlayerInterior(playerid, 1);
	SetPlayerPos(playerid, 0.5613,27.7095,1199.5938);
	SetPlayerFacingAngle(playerid, 1.4162);
	SetPlayerCameraPos(playerid, 1.6183, 29.7605, 1199.2000);
	SetPlayerCameraLookAt(playerid, 1.1574, 28.8746, 1199.3254);
    ApplyAnimation(playerid,  "PED", "SEAT_idle", 1.0, 1, 0, 0, 0, 0); // Pay anim
	SetTimerEx("MudarCameraAviao3", 500, false, "i", playerid);
}
SCBR::MudarCameraAviao3(playerid)
{
	SetPlayerCameraPos(playerid, 2.7904, 24.1120, 1201.3695);
	SetPlayerCameraLookAt(playerid, 2.3023, 24.9832, 1200.9744);
	SetTimerEx("MudarCameraAviao", 5000, false, "i", playerid);
}
SCBR::MudarCameraAviao(playerid)
{
	SetPlayerCameraPos(playerid, 1.6183, 29.7605, 1199.2000);
	SetPlayerCameraLookAt(playerid, 1.1574, 28.8746, 1199.3254);
	SetTimerEx("MudarCameraAviao2", 5000, false, "i", playerid);
}
SCBR::MudarCameraAviao2(playerid)
{
    SetPlayerVirtualWorld(playerid, 0);
    MoveObject(ObjetoAviao[playerid], 1712.90784, -2492.18359, 15.69070, 30);
	SetPlayerInterior(playerid, 0);
	SetPlayerCameraPos(playerid, 1632.0120, -2512.9741, 15.1981);
	SetPlayerCameraLookAt(playerid, 1632.9968, -2512.8066, 15.3631);
	SetTimerEx("RemoverAviao", 15000, false, "i", playerid);
}
SCBR::RemoverAviao(playerid)
{
    DestroyObject(ObjetoAviao[playerid]);
	SetPlayerVirtualWorld(playerid, 0);
	SetTimerEx("SpawnPlayer", 1000, false, "i", playerid);
	if(PlayerInfo[playerid][Sexo] == 1)
	{
	    SetSpawnInfo(playerid, 0, 37, 1685.4121,-2333.7273,13.5469, 0, 0, 0, 0, 0, 0, 0);
	    TogglePlayerSpectating(playerid, false);
	    Limparchat(playerid);
	    SendClientMessage(playerid, -1, "{00FF00}==============================================");
	    SendClientMessage(playerid, -1, "{FFFFFF} Bem Vindo ao Street Of Caminhoneiro");
	    SendClientMessage(playerid, -1, "{FFFFFF} Divirta-se Pelas as Estradas de San Andreas");
	    SendClientMessage(playerid, -1, "{00FF00}==============================================");
	   	SpawnPlayer(playerid);
	}
	if(PlayerInfo[playerid][Sexo] == 2)
	{
	    SetSpawnInfo(playerid, 0, 38, 1685.4121,-2333.7273,13.5469, 0, 0, 0, 0, 0, 0, 0);
	    TogglePlayerSpectating(playerid, false);
	    Limparchat(playerid);
	    SendClientMessage(playerid, -1, "{00FF00}==============================================");
	    SendClientMessage(playerid, -1, "{FFFFFF} Bem Vinda ao Street Of Caminhoneiro");
	    SendClientMessage(playerid, -1, "{FFFFFF} Divirta-se Pelas as Estradas de San Andreas");
	    SendClientMessage(playerid, -1, "{00FF00}==============================================");
	   	SpawnPlayer(playerid);
	}
}
SaveCarNomePlay(playerid){
	new name[24], full[50];
	GetPlayerName(playerid,name,sizeof(name));
	format(full,sizeof(full),"%s/%s.txt",PATH,name);
	return full;
}
stock AlguemNoCarro(carroid){
	for (new i = 0; i < MAX_PLAYERS; i++)
		if (IsPlayerConnected(i))
		    if(GetPlayerVehicleID(i) == carroid){
				return 1;
			}
	return 0;
}
