#include <a_samp>
#include <DOF2>

#define DIALOG_REGISTRO 1
#define DIALOG_LOGIN 2

enum pInfo
{
	 Senha,
	 Dinheiro,
	 Skin,
	 Admin,
	 Level
};

new PlayerInfo[MAX_PLAYERS][pInfo];
new string[256];
new arquivo[256];
new MotoSpawn[8];
public OnGameModeInit()
{
	SetGameModeText("USRP v0.0.1");
	//Bikes Spawn
	MotoSpawn[0] = CreateVehicle(462,-1434.5770,-278.5997,13.7532,132.4642,1,1,false); // bike 1
	MotoSpawn[1] = CreateVehicle(462,-1432.2179,-280.0795,13.7360,131.2119,1,1,false); // bike 2
	MotoSpawn[2] = CreateVehicle(462,-1430.1504,-281.4629,13.7411,119.8947,1,1,false); // bike 3
	MotoSpawn[3] = CreateVehicle(462,-1415.9939,-292.3855,13.7506,118.6660,1,1,false); // bike 4
	MotoSpawn[4] = CreateVehicle(462,-1414.0067,-294.4715,13.7461,116.3829,1,1,false); // bike 5
	MotoSpawn[5] = CreateVehicle(462,-1411.9648,-296.0332,13.7437,109.8035,1,1,false); // bike 6
	MotoSpawn[6] = CreateVehicle(462,-1418.5453,-290.2483,13.7482,118.6820,1,1,false); // bike 7
	MotoSpawn[7] = CreateVehicle(462,-1427.6735,-283.0393,13.7427,123.7448,1,1,false); // bike 8
	return 1;
}

public OnGameModeExit()
{
	DOF2_Exit();
	return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
	return 0;
}

public OnPlayerConnect(playerid)
{
    format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
	if(!DOF2_FileExists(arquivo))
	{
        format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) ao Servidor\nNome: {708090}%s\n{FFFFFF}Conta: {FF0000}Nao Registrada\n{FFFFFF}Digite sua senha de Registro", PlayerName(playerid));
	    ShowPlayerDialog(playerid, DIALOG_REGISTRO, DIALOG_STYLE_PASSWORD, "Registro", string, "Registrar", "Cancelar");
		return 1;
	}
    format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
    ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
	return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    SalvarDados(playerid);
	return 1;
}

public OnPlayerSpawn(playerid)
{
	return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
	return 1;
}

public OnVehicleSpawn(vehicleid)
{
	return 1;
}

public OnVehicleDeath(vehicleid, killerid)
{
	return 1;
}

public OnPlayerText(playerid, text[])
{
	return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
	if (strcmp("/mycommand", cmdtext, true, 10) == 0)
	{
		// Do something here
		return 1;
	}
	return 0;
}

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
	return 1;
}

public OnPlayerExitVehicle(playerid, vehicleid)
{
	return 1;
}

public OnPlayerStateChange(playerid, newstate, oldstate)
{
	return 1;
}

public OnPlayerEnterCheckpoint(playerid)
{
	return 1;
}

public OnPlayerLeaveCheckpoint(playerid)
{
	return 1;
}

public OnPlayerEnterRaceCheckpoint(playerid)
{
	return 1;
}

public OnPlayerLeaveRaceCheckpoint(playerid)
{
	return 1;
}

public OnRconCommand(cmd[])
{
	return 1;
}

public OnPlayerRequestSpawn(playerid)
{
	return 1;
}

public OnObjectMoved(objectid)
{
	return 1;
}

public OnPlayerObjectMoved(playerid, objectid)
{
	return 1;
}

public OnPlayerPickUpPickup(playerid, pickupid)
{
	return 1;
}

public OnVehicleMod(playerid, vehicleid, componentid)
{
	return 1;
}

public OnVehiclePaintjob(playerid, vehicleid, paintjobid)
{
	return 1;
}

public OnVehicleRespray(playerid, vehicleid, color1, color2)
{
	return 1;
}

public OnPlayerSelectedMenuRow(playerid, row)
{
	return 1;
}

public OnPlayerExitedMenu(playerid)
{
	return 1;
}

public OnPlayerInteriorChange(playerid, newinteriorid, oldinteriorid)
{
	return 1;
}

public OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
	return 1;
}

public OnRconLoginAttempt(ip[], password[], success)
{
	return 1;
}

public OnPlayerUpdate(playerid)
{
	return 1;
}

public OnPlayerStreamIn(playerid, forplayerid)
{
	return 1;
}

public OnPlayerStreamOut(playerid, forplayerid)
{
	return 1;
}

public OnVehicleStreamIn(vehicleid, forplayerid)
{
	return 1;
}

public OnVehicleStreamOut(vehicleid, forplayerid)
{
	return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_REGISTRO)
    {
        if(response)
        {
            if(strlen(inputtext) >= 5 && strlen(inputtext) <= 10)
            {
                format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
	            DOF2_CreateFile(arquivo);
	   			DOF2_SetString(arquivo, "Senha", inputtext);
	            DOF2_SetInt(arquivo, "Dinheiro", 0);
	            DOF2_SetInt(arquivo, "Skin", 0);
	            DOF2_SetInt(arquivo, "Admin", 0);
	            DOF2_SetInt(arquivo, "Level", 0);
	            DOF2_WriteFile();
				GivePlayerMoney(playerid, 1000);
				SetPlayerSkin(playerid, 26);
				SetSpawnInfo(playerid, 0, 26, -1421.1062,-287.0277,14.1484, 0, 0, 0, 0, 0, 0, 0);
	            SpawnPlayer(playerid);
			}
			else
			{
			    SendClientMessage(playerid, -1, "{FF0000}[ERRO] Digite Caracteres entre 5 a 10.");
			    format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) ao Servidor\nNome: {708090}%s\n{FFFFFF}Conta: {FF0000}Nao Registrada\n{FFFFFF}Digite sua senha de Registro", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_REGISTRO, DIALOG_STYLE_PASSWORD, "Registro", string, "Registrar", "Cancelar");
			}
		}
		else
		{
		    Kick(playerid);
		}
	}
	if(dialogid == DIALOG_LOGIN)
	{
	    if(response)
	    {
	        if(!strlen(inputtext))
	        {
	            format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
	            return 1;
			}
			format(arquivo, sizeof(arquivo), "Contas/%s.txt", PlayerName(playerid));
			if(strcmp(inputtext, DOF2_GetString(arquivo, "Senha"), true))
            {
	            format(string, sizeof(string), "{FFFFFF}Bem Vindo(a) Novamente\nNome: {708090}%s\n{FFFFFF}Conta: {00FF00}Registrada\n{FFFFFF}Digite sua senha de login", PlayerName(playerid));
        		ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, "Login", string, "Logar", "Cancelar");
				SendClientMessage(playerid, -1, "{FF0000}[ERRO] Senha Incorreta Digite Novamente");
			}
			else
			{
	   			PlayerInfo[playerid][Dinheiro] = DOF2_GetInt(arquivo, "Dinheiro");
	      		PlayerInfo[playerid][Skin] = DOF2_GetInt(arquivo, "Skin");
	        	PlayerInfo[playerid][Admin] = DOF2_GetInt(arquivo, "Admin");
	        	PlayerInfo[playerid][Level] = DOF2_GetInt(arquivo, "Level");
	        	GivePlayerMoney(playerid, PlayerInfo[playerid][Dinheiro]);
			    SendClientMessage(playerid, -1, "{00FF00} Bem Vindo(a) Novamente ao USRP");
			    SetSpawnInfo(playerid, 0, PlayerInfo[playerid][Skin], -1421.1062,-287.0277,14.1484, 0, 0, 0, 0, 0, 0, 0);
				SpawnPlayer(playerid);
			}
		}
		else
		{
			Kick(playerid);
		}
	}
	return 1;
}

public OnPlayerClickPlayer(playerid, clickedplayerid, source)
{
	return 1;
}

stock PlayerName(playerid)
{
	new sendername[MAX_PLAYER_NAME];
	GetPlayerName(playerid, sendername, sizeof(sendername));
	return ( sendername );
}
stock SalvarDados(playerid)
{
    format(arquivo, sizeof(arquivo), "Contas/%s.txt",PlayerName(playerid));
    DOF2_SetInt(arquivo, "Dinheiro", GetPlayerMoney(playerid));
    DOF2_SetInt(arquivo, "Skin", PlayerInfo[playerid][Skin]);
    DOF2_SetInt(arquivo, "Admin", PlayerInfo[playerid][Admin]);
    DOF2_SetInt(arquivo, "Level", PlayerInfo[playerid][Level]);
    DOF2_SaveFile();
    return 1;
}
